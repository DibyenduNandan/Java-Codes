package com.book.portal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.book.portal.controllers.AuthorController;
import com.book.portal.controllers.PublisherController;
import com.book.portal.dao.AuthorServiceImpl;
import com.book.portal.dao.PublisherServiceImpl;
import com.book.portal.entities.Author;
import com.book.portal.entities.Publisher;
import com.book.portal.exception.AuthorException;
import com.book.portal.exception.PublisherException;

@SpringBootTest
class PublisherTest {
	
	@Mock PublisherServiceImpl service;

	@InjectMocks PublisherController controller;

	@Test
	void test() {
		String id="0736";
		Publisher expected= new Publisher(id,"New Moon Book","Kolkata","WB","India");
		try {
			when(service.getDetailsById(id)).thenReturn(expected);
			Publisher actual=controller.getPublisherById(id);
			assertNotNull(actual);
			assertEquals(expected.getPubId(), actual.getPubId());
			assertEquals(expected.getPubName(), actual.getPubName());
			assertEquals(expected.getCity(), actual.getCity());
			assertEquals(expected.getState(), actual.getState());
			assertEquals(expected.getCountry(), actual.getCountry());	
			verify(service, times(1)).getDetailsById(id);
		} catch (PublisherException e) {
			System.out.println("There is a exception");
		}
	}

}
