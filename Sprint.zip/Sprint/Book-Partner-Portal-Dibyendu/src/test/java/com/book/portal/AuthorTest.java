package com.book.portal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.book.portal.controllers.AuthorController;
import com.book.portal.dao.AuthorServiceImpl;
import com.book.portal.entities.Author;
import com.book.portal.exception.AuthorException;

@SpringBootTest
public class AuthorTest {

	@Mock AuthorServiceImpl service;

	@InjectMocks AuthorController controller;

	@Test
	public void testAuthorById() {
		String id="123-45-6789";
		Author expected= new Author(id,"Smith","John","123-456-7890","123 Main St","New York","NY","10001",1);
		try {
			when(service.getAuthorById(id)).thenReturn(expected);
			Author actual=controller.getAuthorById(id);
			assertNotNull(actual);
			assertEquals(expected.getId(), actual.getId());
			assertEquals(expected.getFirstname(), actual.getFirstname());
			assertEquals(expected.getLastname(), actual.getLastname());
			assertEquals(expected.getPhone(), actual.getPhone());
			assertEquals(expected.getAddress(), actual.getAddress());
			assertEquals(expected.getCity(), actual.getCity());
			assertEquals(expected.getState(), actual.getState());
			assertEquals(expected.getContract(), actual.getContract());
			verify(service, times(1)).getAuthorById(id);
		} catch (AuthorException e) {
			System.out.println("There is a exception");
		}
	}
}
