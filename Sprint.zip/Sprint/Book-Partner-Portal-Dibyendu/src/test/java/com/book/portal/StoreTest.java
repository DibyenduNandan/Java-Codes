package com.book.portal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.book.portal.controllers.StoreController;
import com.book.portal.dao.StoreServiceImpl;
import com.book.portal.entities.Store;
import com.book.portal.exception.StoreException;

@SpringBootTest
class StoreTest {

	@Mock StoreServiceImpl service;

	@InjectMocks StoreController controller;

	@Test
	void test() {
		String id = "6380";
		Store expected = new Store(id,"Eric the Read Books","788 Catamaugus Ave.","Seattle","WA","98056");
		try {
			when(service.getStoreById(id)).thenReturn(expected);
			Store actual = controller.getStoreById(id);
			assertNotNull(actual);
			assertEquals(expected.getStorId(), actual.getStorId());
			assertEquals(expected.getStorName(), actual.getStorName());
			assertEquals(expected.getStorAddress(), actual.getStorAddress());
			assertEquals(expected.getCity(), actual.getCity());
			assertEquals(expected.getState(), actual.getState());
			assertEquals(expected.getZip(), actual.getZip());
			verify(service, times(1)).getStoreById(id);
		} catch (StoreException e) {
			System.out.println("There is a exception");
		}
	}

}
