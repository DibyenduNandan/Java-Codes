package com.book.portal.entities;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import jakarta.persistence.*;
 
//The entity annotation specifies that the job class is an entity and is mapped 
//to a database table.
@Entity
@Table(name = "jobs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Job {
	// This id annotation is used for creating primary key on job id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "job_id", nullable = false)
    private Short jobId;
 
    @Column(name = "job_desc", length = 50, nullable = false, columnDefinition = "varchar(50) default 'New Position - title not formalized yet'")
    private String jobDesc = "New Position - title not formalized yet";
 
    @Column(name = "min_lvl", nullable = false)
    private int minLvl;
 
    @Column(name = "max_lvl", nullable = false)
    private int maxLvl;
 
}
