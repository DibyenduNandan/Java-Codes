package com.book.portal.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.book.portal.entities.Job;

public interface JobRepos extends JpaRepository<Job, Short> {
	

}
