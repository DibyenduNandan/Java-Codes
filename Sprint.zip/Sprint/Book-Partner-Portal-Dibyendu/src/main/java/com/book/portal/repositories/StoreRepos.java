package com.book.portal.repositories;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Store;

//Interface created for Store Class
public interface StoreRepos extends JpaRepository<Store, String>{
	
	
	
	@Query("select s from Store s where s.storName=:s1")
	public Store findByStorName(@Param("s1") String storName);
	
	@Query("select s from Store s where s.city=:c1")
	public List<Store> findByCity(@Param("c1") String city);
}
