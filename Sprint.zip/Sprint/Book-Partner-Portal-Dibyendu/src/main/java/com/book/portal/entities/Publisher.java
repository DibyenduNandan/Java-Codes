package com.book.portal.entities;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity
@Table(name = "publishers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Publisher {    //ENTITY CLASS CREATED
	 @Id
	    @Column(name = "pub_id", length = 4, nullable = false, columnDefinition = "char(4)")
	    @Pattern(regexp = "^(1389|0736|0877|1622|1756|99[0-9][0-9])$", message = "pub_id must match one of the specified values or the pattern 99XX")
	    private String pubId;
	 
	    @Column(name = "pub_name", length = 40)
	    private String pubName;
	 
	    @Column(name = "city", length = 20)
	    private String city;
	 
	    @Column(name = "state", length = 2,columnDefinition = "char(2)")
	    private String state;
	 
	    @Column(name = "country", length = 30, nullable = false, columnDefinition = "varchar(30) default 'USA'")
	    private String country = "USA";
}
