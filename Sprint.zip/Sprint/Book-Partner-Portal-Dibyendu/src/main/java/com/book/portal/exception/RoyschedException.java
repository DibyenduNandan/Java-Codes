package com.book.portal.exception;

public class RoyschedException extends Exception{
	
	public RoyschedException(String message) {
		super(message);
	}

}



