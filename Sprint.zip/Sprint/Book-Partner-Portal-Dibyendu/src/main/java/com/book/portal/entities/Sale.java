package com.book.portal.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Entity
@Table(name = "sales")
@Data
@NoArgsConstructor
@AllArgsConstructor
@IdClass(SaleId.class)
public class Sale {		//Entity created for Sale Class

	@Id
	@Column(name="ord_num", nullable = false, length = 20)
	private String orderNum;

	//Created a relationship between many sales to the store
	@ManyToOne
	@Id
	@JoinColumn(name = "stor_id", referencedColumnName = "stor_id", columnDefinition = "char(4)")
	private Store store;

	//Created a relationship between many sales to the store
	@ManyToOne
	@Id
	@JoinColumn(name = "title_id", referencedColumnName = "title_id")
	private Title title;

	@Column(name = "ord_date", nullable = false)
	private Timestamp ordDate;

	@Column(name = "qty", nullable = false)
	private Short qty;

	@Column(name = "payterms", length = 12, nullable = false)
	private String payterms;

}

