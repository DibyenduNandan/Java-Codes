package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Roysched;
import com.book.portal.exception.RoyschedException;
import com.book.portal.repositories.RoyschedRepos;
import com.book.portal.services.RoyschedService;

@Component
public class RoyschedServiceImpl implements RoyschedService {
	
	@Autowired
	private RoyschedRepos roysched;

	//This method calls the `findAll` method on the `roysched` repository 
//	 or service to fetch all entries of type Roysched. It is expected to 
//	  return a List of Roysched objects.
	@Override
	public List<Roysched> getAllRoyscheds() {
	
		return roysched.findAll();
	}

//	Retrieves a Roysched object by its ID.
//	If a Roysched with the given ID exists, it is returned. 
//	  Otherwise, a RoyschedException is thrown.
	
	@Override
	public Roysched getRoyschedById(int id)throws RoyschedException {
		Optional<Roysched> opt = roysched.findById(id);
        if (opt.isPresent()) 
        	return opt.get();
        throw new RoyschedException("Roysched not found with ID: " + id);
        
       
	}

//	Finds Royscheds by royalty. 
//	 Throws an exception if no records are found.
	
	@Override
	public List<Roysched> findByRoyalty(int royalty)throws RoyschedException {
		List<Roysched> royscheds = roysched.findByRoyalty(royalty);
        if (royscheds.size()==0) {
            throw new RoyschedException("No Roysched records found with royalty: " + royalty);
        }
        return royscheds;
	}

//	Retrieves Royscheds within the specified range between 1001 to 8001
//	 Throws an exception if no records are found in that range
	@Override
	public List<Roysched> getRoyschedByRange(int lrangeStart, int hirangeEnd)throws RoyschedException {
		List<Roysched> royscheds = roysched.findByLrangeGreaterThanEqualAndHrangeLessThanEqual(lrangeStart, hirangeEnd);
        if (royscheds.size()==0) {
            throw new RoyschedException("No Roysched records found in range: " + lrangeStart + " to " + hirangeEnd);
        }
        return royscheds;
	}

}


