package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Store;
import com.book.portal.exception.StoreException;

//Interface service created for Store
public interface StoreService {
	
	public List<Store> getAllStores();
	
	public Store getStoreById(String storId) throws StoreException;
	
	public Store getStoreByName(String storName) throws StoreException;
	
	public List<Store> getStoresByCity(String city) throws StoreException;
}
