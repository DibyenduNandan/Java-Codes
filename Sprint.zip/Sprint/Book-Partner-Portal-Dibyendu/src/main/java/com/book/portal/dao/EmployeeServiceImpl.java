package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Employee;
import com.book.portal.exception.EmployeeException;
import com.book.portal.repositories.EmployeeRepos;
import com.book.portal.services.EmployeeService;

@Component
public class EmployeeServiceImpl implements EmployeeService{   //IMPLEMENAATION OF EmployeeService class
	@Autowired
	private EmployeeRepos empRepos;
	

	
	@Override
	public List<Employee> getAllEmployee(){				//FETCH ALL EMPLOYEE RECORD
		return empRepos.findAll();
	}

	
	//FETCH EMPLOYEE BY NAME
	@Override
	public Employee getEmployeesByName(String fname)throws EmployeeException {
		Employee emp;
		emp =  empRepos.findEmployeeByName(fname);
		if(emp!=null) {
			return emp;
		}else {
			throw new EmployeeException("No employee found with the given name");
		}
	}
	
	//FETCH EMPLOYEE BY ID
	@Override
	public Employee getEmployeeById(String empId) throws EmployeeException {
		Optional<Employee> op =  empRepos.findById(empId);
		if(op.isPresent())
			return (Employee)op.get();
			throw new EmployeeException("No employee exist with the given Id");
		
	}


}
