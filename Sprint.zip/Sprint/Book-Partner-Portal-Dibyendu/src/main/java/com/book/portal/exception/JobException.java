package com.book.portal.exception;

public class JobException extends Exception {
	
	public JobException(String message) {
		super(message);
	}
	

}
