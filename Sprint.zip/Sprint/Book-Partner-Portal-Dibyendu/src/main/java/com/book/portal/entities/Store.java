package com.book.portal.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity
@Table(name = "stores")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Store {		//Enitity Created for Store Class

	@Id
	@Column(name = "stor_id", length = 4, nullable = false, columnDefinition = "char(4)")
	private String storId;

	@Column(name = "stor_name", length = 40)
	private String storName;

	@Column(name = "stor_address", length = 40)
	private String storAddress;

	@Column(name = "city", length = 20)
	private String city;	

	@Column(name = "state", length = 2, columnDefinition = "char(2)")
	private String state;

	@Column(name = "zip", length = 5, columnDefinition = "char(5)")
	private String zip;
}