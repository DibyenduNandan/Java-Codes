package com.book.portal.entities;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

//The entity annotation specifies that the roysched class is an entity and is mapped 
//to a database table.
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class Roysched {
	// This id annotation is used for creating primary key on roysched id
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="roysched_id")
	private int id;
	@Column(name="lorange")
	private int lrange;
	@Column(name="hirange")
	private int hrange;
	@Column(name="royalty")
	private int royalty;
	
	//Maps this entity to the Title entity with a many-to-one relationship.
	//The foreign key column is `title_id`
	
	@ManyToOne
	@JoinColumn(name = "title_id",columnDefinition = "varchar(10)",referencedColumnName = "title_id")
	Title title;
 
}