package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Store;
import com.book.portal.exception.StoreException;
import com.book.portal.repositories.StoreRepos;
import com.book.portal.services.StoreService;

@Component
public class StoreServiceImpl implements StoreService {		//Implements the Service interface of Store
	
	@Autowired
	private StoreRepos store;
	

	@Override
	public List<Store> getAllStores() {
		return store.findAll();
	}

	@Override
	public Store getStoreByName(String storName) throws StoreException{
		Store s;
		s = store.findByStorName(storName);
		if (s != null) {
			return s;
		}else {
			throw new StoreException("No store found by given name");
		}
	}

	@Override
	public List<Store> getStoresByCity(String city) throws StoreException{
		List<Store> list = store.findByCity(city);
		
		if (list.size()==0) {
			throw new StoreException("No store found by given city");
		}
		return list;
	}

	@Override
	public Store getStoreById(String storId) throws StoreException {
		Optional<Store> optional = store.findById(storId);
		if(optional.isPresent())
			return optional.get();
		throw new StoreException("No such store by the ID");
		
	}

	
	
	
	
	
	
}
