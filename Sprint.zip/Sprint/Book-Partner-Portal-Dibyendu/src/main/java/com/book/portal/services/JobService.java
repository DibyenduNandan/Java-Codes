package com.book.portal.services;

import java.util.List;
import java.util.Optional;

import com.book.portal.entities.Job;
import com.book.portal.exception.JobException;

public interface JobService {
	
	public List<Job> getAllJobDescription();
	public  Optional<Job> getJobById(Short id)throws JobException;

}
