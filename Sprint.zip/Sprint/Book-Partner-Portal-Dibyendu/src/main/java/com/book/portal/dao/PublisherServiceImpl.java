 package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Publisher;
import com.book.portal.exception.PublisherException;
import com.book.portal.repositories.PublisherRepos;
import com.book.portal.services.PublisherService;

@Component
public class PublisherServiceImpl implements PublisherService {    //IMPLEMENTATION OF PublisherService
	@Autowired
	private PublisherRepos pubs;

	@Override
	public List<Publisher> getAllPublisher() {  //FIND ALL PUBLISHER 
		
		return pubs.findAll();
	}
	
	
	//FETCH PUBLISHER DETAILS BY ID
	@Override
	public Publisher getDetailsById(String id) throws PublisherException{      
		Optional<Publisher> opt =  pubs.findById(id);
		if(opt.isPresent())
			return (Publisher)opt.get();
		throw new PublisherException("No publisher with the given ID");
	}
	
	
	//FETCH PUBLISHER DEAILS BY STATE
	@Override
	public List<Publisher> filterPublisherByState(String state)throws PublisherException{
		
		List<Publisher> list = pubs.getPublisherByState(state);
		if(list.size()==0) 	
			throw new PublisherException("No Publisher in the state");return list;
		
	}
	
	
	//COUNT NUMBER OF PUBLISHER PER CITY
	@Override
	public int countPerCity(String city) {
		return pubs.countByCity(city);
	}
	
	
}
