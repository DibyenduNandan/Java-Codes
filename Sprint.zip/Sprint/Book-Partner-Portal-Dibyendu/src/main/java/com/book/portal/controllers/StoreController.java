package com.book.portal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.StoreServiceImpl;
import com.book.portal.entities.Store;
import com.book.portal.exception.StoreException;

@RestController
@RequestMapping(path="/api")
public class StoreController {		//Controller created for Store Class
	
	@Autowired
	StoreServiceImpl service;
	
	@GetMapping("/stores")
	public List<Store> getAllStores() {
		return service.getAllStores();
	}
	
	@GetMapping("/store-id/{stor_id}")
	public Store getStoreById(@PathVariable("stor_id") String storeId) throws StoreException{
		return service.getStoreById(storeId);
	}
	
	@GetMapping("/stores-by-name/{stor_name}")
	public Store getStoreByName(@PathVariable("stor_name") String storName) throws StoreException {
		return service.getStoreByName(storName);
	}
	
	@GetMapping("/stores-by-city/{city}")
	public List<Store> getStoresByCity(@PathVariable("city") String city) throws StoreException{
		return service.getStoresByCity(city);
	}
}
