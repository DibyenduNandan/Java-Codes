package com.book.portal.services;

import java.util.List;


import com.book.portal.entities.Roysched;
import com.book.portal.exception.RoyschedException;

public interface RoyschedService {
	
	public List<Roysched> getAllRoyscheds();
	public Roysched getRoyschedById(int id)throws RoyschedException;
	public List<Roysched> findByRoyalty(int royalty)throws RoyschedException;
	public List<Roysched> getRoyschedByRange(int lrangeStart,  int hirangeEnd)throws RoyschedException;
	

}

