package com.book.portal.entities;

import java.io.Serializable;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//This class used for creating a composite key
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SaleId implements Serializable {
	
    private String store;
    private String orderNum;
    private String title;
    
}
 
