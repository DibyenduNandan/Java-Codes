package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Job;
import com.book.portal.exception.JobException;
import com.book.portal.repositories.JobRepos;
import com.book.portal.services.JobService;

@Component
public class JobServiceImpl implements JobService{
	
	@Autowired
	private JobRepos job;

	//This method calls the `findAll` method on the `job` repository 
//	 or service to fetch all entries of type job. It is expected to 
//	  return a List of job objects.
	@Override
	public List<Job> getAllJobDescription() {
		
		return job.findAll();
	}

	
//	Retrieves a job object by its ID.
//	If a job with the given ID exists, it is returned.
//	 Otherwise, a JobException is thrown.

	@Override
	public Optional<Job> getJobById(Short id)throws JobException {
		Optional<Job> o= job.findById(id);
        if (o.isPresent()) 
        	return o; 
        throw new JobException("Job not found with ID: " + id);
	}
	}


