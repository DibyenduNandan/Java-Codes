package com.book.portal.exception;

//Custom Exception created for Store Class
public class StoreException extends Exception {
	
	public StoreException(String message) {
		super(message);
	}
}
