package com.book.portal.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.SaleServiceImpl;
import com.book.portal.entities.Sale;
import com.book.portal.exception.SaleException;
import com.book.portal.services.SaleService;


@RestController
@RequestMapping(path="/api")
public class SaleController {		//Controller created for Sale Class

	@Autowired
	private SaleServiceImpl service;

	@GetMapping("/sales")
	public List<Sale> getAllSales() {
		return service.getAllSales();
	}

	@GetMapping("/sales/payterms/{payterms}")
	public List<Sale> getSalesByPayterms(@PathVariable("payterms") String payterms) throws SaleException {
		return service.getSalesByPayterms(payterms);
	}

}
