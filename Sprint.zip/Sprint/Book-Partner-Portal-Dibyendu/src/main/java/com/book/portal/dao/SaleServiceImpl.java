package com.book.portal.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.book.portal.entities.Sale;
import com.book.portal.exception.SaleException;
import com.book.portal.repositories.SaleRepos;
import com.book.portal.services.SaleService;

@Service
public class SaleServiceImpl implements SaleService{	//Implements the service of Sale 
	
	@Autowired
	private SaleRepos sale;
	
	@Override
	public List<Sale> getAllSales() {
		return sale.findAll();
	}
	
	@Override
	public List<Sale> getSalesByPayterms(String payterms) throws SaleException {
		List<Sale> list = sale.findByPayterms(payterms);
		
		if (list.size() == 0) {
			throw new SaleException("No sale found by given payterms");
		}
		return list;
	}

}
