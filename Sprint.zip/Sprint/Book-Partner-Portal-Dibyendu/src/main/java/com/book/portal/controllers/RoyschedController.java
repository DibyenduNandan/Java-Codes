package com.book.portal.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.book.portal.dao.RoyschedServiceImpl;

import com.book.portal.entities.Roysched;
import com.book.portal.exception.RoyschedException;

@RestController
@RequestMapping(path="/api")
public class RoyschedController {
	
	@Autowired
	RoyschedServiceImpl service;
	
	//Getting all royscheds from the server
	@GetMapping("/all-royscheds")
	public List<Roysched> getAllRoyscheds(){
		return service.getAllRoyscheds();
	}
	
	//Getting roysched by roysched id from the server
	@GetMapping("/royscheds/{roysched_id}")
	public Roysched getRoyschedById(@PathVariable("roysched_id") int id)throws RoyschedException  {
        return service.getRoyschedById(id);
}
	
	//Getting royscheds by giving the royality from the server
	@GetMapping("/royscheds-get-by-royalty/{royalty}")
	public List<Roysched> getRoyschedByRoyalty(@PathVariable("royalty")int royalty)throws RoyschedException {
		return service.findByRoyalty(royalty);
	}
	
	//Getting royscheds by giving the roysched  range from 1001 to 8001 from the server
	@GetMapping("/royscheds/range")
    public List<Roysched> getRoyschedByRange(
            @RequestParam(value = "lorangeStart", required = false, defaultValue = "1001") int lorangeStart,
            
            @RequestParam(value = "hirangeEnd", required = false, defaultValue = "8001") int hirangeEnd) throws RoyschedException {
        		return service.getRoyschedByRange(lorangeStart,  hirangeEnd);
    }
		
	}



