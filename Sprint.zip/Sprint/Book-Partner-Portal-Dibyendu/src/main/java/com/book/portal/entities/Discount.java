package com.book.portal.entities;

import java.math.BigDecimal;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity //marking the Title class as a JPA entity.
@Table(name ="discounts") //naming the table as discounts.
@IdClass(DiscountId.class)
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Discount{
 
	@Id //specifying the Id column as primary key.
    @Column(name="discounttype", length=40,nullable = false) //providing column names. 
    private String discountType;
    @Id
    @ManyToOne ////specifying the annotated field store as a many to one relationship.
    @JoinColumn(name="stor_id", referencedColumnName="stor_id",columnDefinition="char(4)")
    private Store store;
    @Column(name="lowqty")
    private Short lowQty;
    @Column(name="highqty")
    private Short highQty;
    @Column(name="discount", nullable=false, precision=4,scale=2)
    private BigDecimal discount;
	public BigDecimal getDiscount() { //getter method for discount. 
		return discount;
	}
	public void setDiscount(BigDecimal discount) { //setter method for discount.
        this.discount = discount;
    }
    
}
