package com.book.portal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.EmployeeServiceImpl;
import com.book.portal.entities.Employee;
import com.book.portal.exception.EmployeeException;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeServiceImpl employeeService;
	

	
	@GetMapping("/get-all-employee")   //THIS ROUTES RETURNS THE LIST OF ALL EMPLOYEES
	public List<Employee> getAllEmployee(){
		return employeeService.getAllEmployee();
	}
	
	@GetMapping("/get-by-name/{fname}")   //THIS ROUTES RETURNS EMPLOYEE BY A SPECIFIC NAME
	public Employee getByName(@PathVariable("fname") String fname)throws EmployeeException{
		return employeeService.getEmployeesByName(fname);
	}
	
	@GetMapping("/get-by-id/{emp_id}")			//THIS ROUTES RETURNS EMPLOYEE BY A SPECIFIC ID 
	public Employee getById(@PathVariable("emp_id") String empId)throws EmployeeException {
		return employeeService.getEmployeeById(empId);
	}
	
	
	
	
	
	
}
