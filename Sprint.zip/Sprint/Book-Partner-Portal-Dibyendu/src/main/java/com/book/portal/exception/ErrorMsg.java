package com.book.portal.exception;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//Formatting Error Message
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorMsg {
	
	private LocalDate dateOfError;
	private String errorMsg;
}
