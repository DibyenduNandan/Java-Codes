package com.book.portal.exception;

public class DiscountException extends RuntimeException{ //Creating a customized exception class DiscountException
	
	public DiscountException(String message) {
		super(message); //Passing the error message to the parent class constructor which is RuntimeException class
	}

}


