package com.book.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookPartnerPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookPartnerPortalApplication.class, args);
	}

}
