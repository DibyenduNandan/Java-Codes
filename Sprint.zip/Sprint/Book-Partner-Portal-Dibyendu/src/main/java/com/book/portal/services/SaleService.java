package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Sale;
import com.book.portal.exception.SaleException;

//Interface service created for Sale
public interface SaleService {
	
	public List<Sale> getAllSales();

	public List<Sale> getSalesByPayterms(String payterms) throws SaleException;

}
