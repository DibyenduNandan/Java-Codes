package com.book.portal.repositories;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.book.portal.entities.Discount;
import com.book.portal.entities.DiscountId;

@Repository  //helps Spring to detect the repository and handle exceptions
public interface DiscountRepos extends JpaRepository<Discount, DiscountId> { //interface providing CRUD (Create, Read, Update, Delete) operations

	public List<Discount> findByDiscountType(String discounttype);

//	@Query("select d from Discount d")
//	public List<Discount> filterByDiscount();

}


