package com.book.portal.entities;

import java.sql.Timestamp;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity
@Table(name = "employee")
@Data
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class Employee {      //ENTITY CLASS
	@Id
    @Column(name = "emp_id", length = 10, nullable = false)  //nullable attribute means this field cannot be null
    private String empId;
 
    @Column(name = "fname", length = 20, nullable = false)		//nullable attribute means this field cannot be null
    private String fname;
 
    @Column(name = "minit", length = 1,columnDefinition = "char(1)")   //columnDefination defines the column value and type
    private String minit;
 
    @Column(name = "lname", length = 30, nullable = false)
    private String lname;
    
    
    //CREATES A RELATIONSHIP WHERE MANY EMPLOYEES CAN HAVE THE SAME JOB
    @ManyToOne
    @JoinColumn(name = "job_id", referencedColumnName = "job_id", nullable = false)   //
    private Job job;
 
    @Column(name = "job_lvl", nullable = false, columnDefinition = "int default 10")
    private Integer jobLvl = 10;
    
    //CREATES A RELAIONSHIP WHERE MANY EMPLOYEES CAN BE A PART OF SINGLE PUBLISHER
    @ManyToOne
    @JoinColumn(name = "pub_id", referencedColumnName = "pub_id", nullable = false, columnDefinition = "char(4) default '9952'")
    private Publisher publisher;
 
    @Column(name = "hire_date", nullable = false, columnDefinition = "timestamp default current_timestamp()")
    private Timestamp hireDate = new Timestamp(System.currentTimeMillis());
}
