package com.book.portal.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Sale;
import com.book.portal.entities.SaleId;

//Interface created for Sale Class
public interface SaleRepos extends JpaRepository<Sale, SaleId>{
    
    @Query("select s from Sale s where s.payterms=:p1")
    List<Sale> findByPayterms(@Param("p1") String payterms);
}
