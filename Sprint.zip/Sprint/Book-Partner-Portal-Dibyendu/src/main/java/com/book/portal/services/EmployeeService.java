package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Employee;
import com.book.portal.exception.EmployeeException;


//EMPLOYEE SERVICE CREATED
public interface EmployeeService {

	
	public List<Employee> getAllEmployee();
	public Employee getEmployeesByName(String fname)throws EmployeeException;
	public Employee getEmployeeById(String empId)throws EmployeeException;
}
