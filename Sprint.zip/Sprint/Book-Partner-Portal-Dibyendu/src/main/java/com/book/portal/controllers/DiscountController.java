

package com.book.portal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.DiscountServiceImpl;
import com.book.portal.entities.Discount;

@RestController //defining the Title class as a RESTful web service controller.
@RequestMapping(path="/api") //specify the path or URL pattern that a controller or method will handle.

public class DiscountController {

	@Autowired //automatically inject the dependency specified by the field or constructor where it's applied.
	
	DiscountServiceImpl service;
	
	@GetMapping("/get-all-discount/{discounttype}") //maps HTTP GET requests with the URL pattern /get-all-discount/{discounttype} to this method.
	
	public List<Discount> getAllDiscount(@PathVariable("discounttype") String discounttype){ //binds the path variable {discounttype} from the URL to the discounttype parameter in the method.
		return service.getAllDiscount(discounttype); //returns a List<Discount> based on discount type.
	}
	
}


