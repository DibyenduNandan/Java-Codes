package com.book.portal.exception;

//PUBLISHER EXEPTION CRERATED(CUSTOM)
public class PublisherException extends Exception {
	public PublisherException(String message) {
		super(message);   //CALLS CONSTRUCTOR FOR PARENT CLASS i.e. Exception
	}
}
