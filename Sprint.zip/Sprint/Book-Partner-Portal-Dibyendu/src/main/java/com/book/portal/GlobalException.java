package com.book.portal;

import java.time.LocalDate;


import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.book.portal.exception.AuthorException;
import com.book.portal.exception.EmployeeException;
import com.book.portal.exception.ErrorMsg;

import com.book.portal.exception.JobException;
import com.book.portal.exception.PublisherException;
import com.book.portal.exception.RoyschedException;


import com.book.portal.exception.SaleException;
import com.book.portal.exception.StoreException;

import com.book.portal.exception.PublisherException;
import com.book.portal.exception.TitleException;



//All the methods present will globally apply to all the controllers
@ControllerAdvice
public class GlobalException {
	
	// The error message will be bound to the web message
	@ExceptionHandler(AuthorException.class)
	public @ResponseBody ErrorMsg checkInvalidAuthor(AuthorException e) {

		ErrorMsg msg=new ErrorMsg(LocalDate.now(), e.getMessage());
		return msg;
	}
	
	// The error message will be bound to the web message
	@ExceptionHandler(StoreException.class)
	public @ResponseBody ErrorMsg checkInvalidStore(StoreException e) {
		ErrorMsg msg=new ErrorMsg(LocalDate.now(), e.getMessage());
		return msg;
	}
	
	// The error message will be bound to the web message
	@ExceptionHandler(SaleException.class)
	public @ResponseBody ErrorMsg checkInvalidSale(SaleException e) {

		ErrorMsg msg=new ErrorMsg(LocalDate.now(), e.getMessage());
		return msg;
	}
	
	
	@ExceptionHandler(EmployeeException.class)
	public @ResponseBody ErrorMsg checkInvalidEmployee(EmployeeException e) {
		ErrorMsg msg = new ErrorMsg(LocalDate.now(),e.getMessage());
		return msg;
	}
	
	@ExceptionHandler(PublisherException.class)
	public @ResponseBody ErrorMsg checkInvalidPublisher(PublisherException e) {
		ErrorMsg msg = new ErrorMsg(LocalDate.now(),e.getMessage());
		return msg;
	}
	

	@ExceptionHandler(RoyschedException.class)
	public @ResponseBody ErrorMsg checkInvalidRoysched(RoyschedException e) {
		ErrorMsg msg = new ErrorMsg(LocalDate.now(),e.getMessage());
		return msg;
	}

	@ExceptionHandler(TitleException.class)
	public @ResponseBody ErrorMsg checkInvalidTitle(TitleException e) {
		ErrorMsg msg = new ErrorMsg(LocalDate.now(),e.getMessage());
		return msg;
	}
	

	@ExceptionHandler(JobException.class)
	public @ResponseBody ErrorMsg checkInvalidJob(JobException e) {
		ErrorMsg msg = new ErrorMsg(LocalDate.now(),e.getMessage());
		return msg;
	}




}
