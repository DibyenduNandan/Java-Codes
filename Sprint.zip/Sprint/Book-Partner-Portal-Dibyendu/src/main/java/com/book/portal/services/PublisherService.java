package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Publisher;
import com.book.portal.exception.PublisherException;


//PUBLISHER SERVICE CREATED
public interface PublisherService {
	
	public List<Publisher> getAllPublisher();
	public Publisher getDetailsById(String id)throws PublisherException;
	public List<Publisher> filterPublisherByState(String state)throws PublisherException;
	public int countPerCity(String city);
}
