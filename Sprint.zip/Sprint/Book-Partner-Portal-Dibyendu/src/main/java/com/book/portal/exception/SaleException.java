package com.book.portal.exception;


//Exception created for Sale Class
public class SaleException extends Exception{
	
	public SaleException(String message) {
		super(message);
	}
}
