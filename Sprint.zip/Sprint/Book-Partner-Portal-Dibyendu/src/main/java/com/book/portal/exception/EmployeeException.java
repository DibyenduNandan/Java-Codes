package com.book.portal.exception;


//EMPLOYEE EXEPTION CREATED(CUSTOM)
public class EmployeeException extends Exception{
	public EmployeeException(String message){
		super(message);  //CALLS THE CONSTRUCTOR OF PARENT CLASS i.e. Exception class
	}
}
