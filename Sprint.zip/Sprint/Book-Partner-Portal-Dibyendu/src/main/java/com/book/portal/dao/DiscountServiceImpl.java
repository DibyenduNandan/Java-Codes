
package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.book.portal.entities.Discount;
import com.book.portal.exception.DiscountException;
import com.book.portal.repositories.DiscountRepos;
import com.book.portal.services.DiscountService;


@Component //automatically detect DiscountServiceImpl class and register it as a bean in the Spring application context.
public class DiscountServiceImpl implements DiscountService {

	@Autowired //automatically inject the dependency specified by the field or constructor where it's applied.
	private DiscountRepos drepos;

	

	@Override
	public List<Discount> getAllDiscount(String discounttype) { //Returns a list of discounts based on discount type
		 List<Discount> discounts = drepos.findByDiscountType(discounttype);

	        if (discounts == null || discounts.isEmpty()) {    //checks if the returned list is null or empty.
	        	
	        	
	        	//If so, it throws a DiscountException with a message indicating that no discounts were found for the given type.
	            throw new DiscountException("No discounts found for type: " + discounttype);
	        }

	       
	        return discounts;
	}
	
	
}


