package com.book.portal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.PublisherServiceImpl;
import com.book.portal.entities.Publisher;
import com.book.portal.exception.PublisherException;

@RestController
@RequestMapping("/api/publisher")
public class PublisherController {

	@Autowired
	 PublisherServiceImpl publisherService;
	
	
	//GET ALL PUBLISHER ROUTE
	@GetMapping("/get-all-publisher")
	public List<Publisher> getAllPublisher(){
		return publisherService.getAllPublisher();
	}
	
	
	//GET PUBLISHER USING SPECIFIC ID
	@GetMapping("/get-details-by-id/{pub_id}")
	public Publisher getPublisherById(@PathVariable("pub_id")String id)throws PublisherException{
		return publisherService.getDetailsById(id);
	}
	
	//FILTER PUBLISHER BY STATE
	@GetMapping("/filter-by-state/{state}")
	public List<Publisher> filterByState(@PathVariable("state")String state)throws PublisherException{
		return publisherService.filterPublisherByState(state);
	}
	
	
	//GET COUNT OF PUBLISHER PER CITY
	@GetMapping("/countpublisher-per-city/{city}")
	public int countPerCity(@PathVariable("city")String city) {
		return publisherService.countPerCity(city);
	}
}
