package com.book.portal.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Roysched;

public interface RoyschedRepos extends JpaRepository<Roysched, Integer>{
	
	@Query("select r from Roysched r where r.royalty>:r1")
	public List<Roysched> findByRoyalty(@Param("r1") int royalty);
	
	public  List<Roysched> findByLrangeGreaterThanEqualAndHrangeLessThanEqual(int lrangeStart, int hirangeEnd);
}



