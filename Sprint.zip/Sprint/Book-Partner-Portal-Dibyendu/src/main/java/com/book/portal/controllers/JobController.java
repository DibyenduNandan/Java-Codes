package com.book.portal.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.JobServiceImpl;
import com.book.portal.entities.Job;
import com.book.portal.exception.JobException;

@RestController
@RequestMapping(path="/api")
public class JobController {
	
	@Autowired
	JobServiceImpl service;
	
	//Getting all jobs description from the server
	@GetMapping("/jobs-desc")
	public List<Job> getAllJobDescription(){
		return service.getAllJobDescription();
	}
	
	
	//Getting job by job id from the server
	@GetMapping("/jobs/{id}")
    public Job getJobById(@PathVariable Short id)throws JobException {
        Optional<Job> o= service.getJobById(id);
        
        if(o.isPresent())
        	return (Job)o.get();
        throw new JobException("No Jobs found");

}
}
