package com.book.portal.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Publisher;

//PUBLISHER REPOSITORY CREATED
public interface PublisherRepos extends JpaRepository<Publisher, String> {
	
	@Query("Select p from Publisher p where p.state=:p1")    //CUSTOM QUERY TO FILTER PUBLISHER BY STATE NAME
	public List<Publisher> getPublisherByState (@Param("p1")String state);
	
	@Query("Select Count(p) from Publisher p where p.city=:p2")   //CUSTOM QUERY TO COUNT THE NUMBER OF PUBLISHER
	public int countByCity(@Param("p2")String city);			//PER CITY
	
}
