package com.book.portal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Employee;


//EMPLOYEE REPOSITORY REATED
public interface EmployeeRepos extends JpaRepository<Employee, String>{

	@Query("Select e from Employee e where e.fname=:a1")     //CUSTOM QUERY TO FETCH EMPLOYEE DETAILS BY NAME
	public Employee findEmployeeByName(@Param("a1")String fname);
}
