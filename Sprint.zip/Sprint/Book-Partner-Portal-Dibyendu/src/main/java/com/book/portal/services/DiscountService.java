package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Discount;

public interface DiscountService {

	public List<Discount> getAllDiscount(String discounttype); //declaring method signature to be implemented in DiscountServiceImpl class.
}


