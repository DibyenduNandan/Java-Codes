package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.portal.entities.Title;
import com.book.portal.exception.TitleException;
import com.book.portal.repositories.TitleRepos;
import com.book.portal.services.TitleService;

@Service //marks a class as a service to define a service layer bean.
public class TitleServiceImpl implements TitleService {

    @Autowired
    private TitleRepos titleRepository;

    
    
    
    
    
    @Override
    public List<Title> getAllTitleName() {  //returns a List of Title objects (all Title names).
        return titleRepository.findAll();
    }

    
    
    
    
    
    @Override
    public Title getTitleById(String titleId)throws TitleException {  //returns an Optional<Title>
        Optional<Title> titleOptional = titleRepository.findById(titleId);
        if (titleOptional.isPresent()) {  //checks if the Optional contains a value. If it does, it means a Title with the specified ID was found.
            return titleOptional.get();
        } else {
            throw new TitleException("Title with ID " + titleId + " not found.");
        }
    }

    
    
    
    
    
    @Override
    public Title getTitleByName(String titleName)throws TitleException {  //returns an instance of the Title class, which represents a title entity.
        Title title = titleRepository.findByTitleName(titleName);
        if (title != null) {
            return title;
        } else {
            throw new TitleException("Title with name " + titleName + " not found.");
        }
    }
   
    
    
    
    
    
    @Override
    public Title getSalesById(String titleId)throws TitleException { //returns an instance of the Title class.
        Optional<Title> titleOptional = titleRepository.findById(titleId);
        if (titleOptional.isPresent()) { //checks if the Optional contains a value. If it does, it means a Title with the specified ID was found.
            return titleOptional.get();
        } else {
            throw new TitleException("Sales information for title ID " + titleId + " not found.");
        }
    }

    
    
    
    
    
	@Override
	 public Title getPriceById(String titleId)throws TitleException { //returns an instance of the Title class.
        Optional<Title> titleOptional = titleRepository.findById(titleId);
        if (titleOptional.isPresent()) { //checks if the Optional contains a value. If it does, it means a Title with the specified ID was found.
            return titleOptional.get();
        } else {
            throw new TitleException("Price information for title ID " + titleId + " not found.");
        }
    }
}

