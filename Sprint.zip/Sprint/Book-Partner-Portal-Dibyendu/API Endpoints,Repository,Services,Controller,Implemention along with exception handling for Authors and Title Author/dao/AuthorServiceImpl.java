package com.book.portal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.portal.entities.Author;
import com.book.portal.exception.AuthorException;
import com.book.portal.repositories.AuthorRepos;
import com.book.portal.services.AuthorService;

@Component
public class AuthorServiceImpl implements AuthorService{
	
	@Autowired
	private AuthorRepos auth;
	
	@Override
	public Author addAuthor(Author obj) {
		// TODO Auto-generated method stub
		return auth.save(obj);
	}
	
	@Override
	public List<Author> getAllAuthor() {
		// TODO Auto-generated method stub
		List<Author> ans=auth.findAll();
		return ans;
	}
	
	@Override
	public List<Author> getAuthorByLastName(String name) throws AuthorException{
		List<Author> ans=auth.getByLastname(name);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by last name");
		return ans;
	}

	@Override
	public List<Author> getAuthorByFirstName(String name) throws AuthorException {
		// TODO Auto-generated method stub
		List<Author> ans=auth.getByFirstname(name);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by first name");
		return ans;
	}

	@Override
	public Author getAuthorById(String id) throws AuthorException {
		// TODO Auto-generated method stub
		Optional<Author> ans=auth.findById(id);
		if(ans.isPresent())
			return (Author)ans.get();
		throw new AuthorException("Author with this au_id not found");
	}
	
	@Override
	public Author getAuthorByPhone(String phone) throws AuthorException {
		// TODO Auto-generated method stub
		Author ans=auth.getByPhone(phone);
		if(ans!=null)
			return ans;
		throw new AuthorException("Author not found by given phone number");
	}
	
	@Override
	public List<Author> getAuthorByZip(String zip) throws AuthorException{
		// TODO Auto-generated method stub
		List<Author> ans=auth.getByZip(zip);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by given zip");
		return ans;
	}
	
	@Override
	public List<Author> getAuthorByCity(String city) throws AuthorException{
		// TODO Auto-generated method stub
		List<Author> ans=auth.getByCity(city);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by from given city");
		return ans;
	}
	
	@Override
	public List<Author> getAuthorByState(String state) throws AuthorException {
		// TODO Auto-generated method stub
		List<Author> ans=auth.getByState(state);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by from given state");
		return ans;
	}

	@Override
	public String getTotalAuthorByCity(String city) throws AuthorException {
		List<Author> ans=auth.getByCity(city);
		if(ans.size()==0)
			throw new AuthorException("Authors not found by from given city");
		return "Total authors present in city : "+city+" is "+ ans.size();
	}

}
