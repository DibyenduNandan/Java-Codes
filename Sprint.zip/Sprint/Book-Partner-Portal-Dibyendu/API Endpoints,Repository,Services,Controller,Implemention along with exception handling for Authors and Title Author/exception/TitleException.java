package com.book.portal.exception;

public class TitleException extends Exception{ //Creating a customized exception class TitleException
	
	public TitleException(String message) {
		super(message); //Passing the error message to the parent class constructor which is Exception class
	}

}
