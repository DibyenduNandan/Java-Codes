package com.book.portal.exception;

//Defining User define Exception for Author Entity
public class AuthorException extends Exception {

	public AuthorException(String msg) {
		super(msg);
	}
	

}
