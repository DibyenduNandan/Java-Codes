package com.book.portal.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Title;

public interface TitleRepos extends JpaRepository<Title, String>{ //interface providing CRUD (Create, Read, Update, Delete) operations

//	List<Title> findByYtdSalesGreaterThan(int sales);
	
	@Query("select t from Title t where t.titleId=:t1")  //specifies a JPQL query to be executed
	public Optional<Title> findById(@Param("t1")String id);

	@Query("select t from Title t where t.title=:t2")  //specifies a JPQL query to be executed
	public Title findByTitleName(@Param("t2")String title);
	

}
