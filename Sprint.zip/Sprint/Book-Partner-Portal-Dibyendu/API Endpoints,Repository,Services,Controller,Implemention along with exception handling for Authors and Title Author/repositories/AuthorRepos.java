package com.book.portal.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.book.portal.entities.Author;


public interface AuthorRepos extends JpaRepository<Author, String>{

	public List<Author> getByLastname(String lastname);

	public List<Author> getByFirstname(String firstname);

	public Author getByPhone(String phone);

	public List<Author> getByZip(String zip);

	public List<Author> getByState(String state);

	public List<Author> getByCity(String city);
}
