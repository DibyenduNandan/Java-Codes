package com.book.portal.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.AuthorServiceImpl;
import com.book.portal.entities.Author;
import com.book.portal.exception.AuthorException;

import jakarta.validation.Valid;

@RestController
@RequestMapping(path="/api")
public class AuthorController {
	
	@Autowired
	AuthorServiceImpl service;
	
	@PostMapping("/authors")
	public Author createAuthor(@Valid @RequestBody Author authObj) {
		return service.addAuthor(authObj);
	}
	
	//We use get when client is asking for information from server
	//Getting all authors from the server
	@GetMapping("/authors")
	public List<Author> getAllAuthor() throws AuthorException{
		List<Author> ans=service.getAllAuthor();
		if(ans.size()==0)
			throw new AuthorException("Authors Not Found");
		return service.getAllAuthor();
	}
	
	
	//Getting author by Id from the server
	@GetMapping("/authors/{au_id}")
	public Author getAuthorById(@PathVariable("au_id") String id) throws AuthorException{
		return service.getAuthorById(id);
	}
	
	//Getting author by lastname from the server
	@GetMapping("/authors/lname/{au_lname}")
	public List<Author> getAuthorByLastName(@PathVariable("au_lname") String name) throws AuthorException{
		return service.getAuthorByLastName(name);
	}
	
	//Getting author by firstname from the server
	@GetMapping("/authors/fname/{au_fname}")
	public List<Author> getAuthorByFirstName(@PathVariable("au_fname") String name) throws AuthorException{
		return service.getAuthorByFirstName(name);
	}
	
	//Getting author by phone number from the server
	@GetMapping("/authors/phone/{phone}")
	public Author getAuthorByPhone(@PathVariable("phone") String phone) throws AuthorException{
		return service.getAuthorByPhone(phone);
	}
	
	//Getting authors who lived in same place from the server
	@GetMapping("/authors/zip/{zip}") 
	public List<Author> getAuthorByZip(@PathVariable("zip") String zip) throws AuthorException{
		return service.getAuthorByZip(zip);
	}
	
	//Getting authors who lived in same state from the server
	@GetMapping("/authors/state/{state}") 
	public List<Author> getAuthorByState(@PathVariable("state") String state) throws AuthorException{
		return service.getAuthorByState(state);
	}
	
	//Getting authors who lived in same city from the server
	@GetMapping("/authors/city/{city}") 
	public List<Author> getAuthorByCity(@PathVariable("city") String city) throws AuthorException{
		return service.getAuthorByCity(city);
	}
	
	//Finding total number of author present in a city from the server
	@GetMapping("/authors/total/{city}") 
	public String getTotalAuthorByCity(@PathVariable("city") String city) throws AuthorException{
		return service.getTotalAuthorByCity(city);
	}
	
}
