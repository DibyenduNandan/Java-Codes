package com.book.portal.controllers;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.portal.dao.TitleServiceImpl;
import com.book.portal.entities.Title;
import com.book.portal.exception.TitleException;

@RestController     //defining the Title class as a RESTful web service controller.
@RequestMapping(path="/api") //specify the path or URL pattern that a controller or method will handle.

public class TitleController {
	
	@Autowired    //automatically inject the dependency specified by the field or constructor where it's applied.
	TitleServiceImpl service;
	
	
	
	
	
	
	@GetMapping("/title-name")    //mapping HTTP GET request to the /title-name URL to this method.
	
	public List<Title> getAllTitleName() {      // returns a List of Title objects.
		return service.getAllTitleName();
		
	}
	
	
	
	
	
	
	@GetMapping("/title-name-ById/{title_id}")  //requests with the URL pattern /title-name-ById/{title_id} to this method.
	
	public Title getTitleById(@PathVariable("title_id") String titleId) throws TitleException{ //binding the path variable {title_id} in the URL to the titleId parameter of the method.
		return service.getTitleById(titleId);  //returns a Title object based on title id.
	}
	
	
	
	
	
	
	@GetMapping("/title-name-ByName/{title}") //maps HTTP GET requests with the URL pattern /title-name-ByName/{title} to this method.
	
	public Title getTitleByName(@PathVariable("title")String title)throws TitleException { //binding the path variable {title} from the URL to the title parameter in the method.
		return service.getTitleByName(title);  //returns a Title object based on the title
	}
	
	
	
	
	
		
	@GetMapping("/title-name-getBySales/{title_id}") //maps HTTP GET requests to the URL pattern /title-name-getBySales/{title_id} to this method.
	
	public Title getTitleBySales(@PathVariable("title_id")String titleId)throws TitleException{ //binding the path variable {title_id} from the URL to the titleId parameter in the method.
		return service.getSalesById(titleId); // returns a Title object based on title id.
	}	
	
	
	
	
	
	
	@GetMapping("/get-price-by-Id/{title_id}") //maps HTTP GET requests with the URL pattern /get-price-by-Id/{title_id} to this method.
	
	public Title getPriceById(@PathVariable("title_id")String titleId)throws TitleException { //binding the path variable {title_id} from the URL to the titleId parameter in the method. 
		return service.getTitleById(titleId); //returns a Title object based on title id.
	}

}
