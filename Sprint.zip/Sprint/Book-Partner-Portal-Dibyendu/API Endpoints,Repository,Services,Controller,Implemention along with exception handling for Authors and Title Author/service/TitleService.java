package com.book.portal.services;

import java.util.List;
import java.util.Optional;

import com.book.portal.entities.Title;
import com.book.portal.exception.TitleException;

public interface TitleService {

	//declaring methods signature to be implemented in TitleServiceImpl class.
    public List<Title> getAllTitleName();
    public Title getTitleById(String titleId)throws TitleException;
    public Title getTitleByName(String title)throws TitleException;
    public Title getSalesById(String titleId)throws TitleException;
    public Title getPriceById(String titleId)throws TitleException;

   
    
	
}
