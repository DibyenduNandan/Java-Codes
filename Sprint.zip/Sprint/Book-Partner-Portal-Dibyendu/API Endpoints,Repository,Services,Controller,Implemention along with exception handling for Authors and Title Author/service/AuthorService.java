package com.book.portal.services;

import java.util.List;

import com.book.portal.entities.Author;
import com.book.portal.exception.AuthorException;

public interface AuthorService {
	
	public Author addAuthor(Author auth);
	public List<Author> getAllAuthor() ;
	public List<Author> getAuthorByLastName(String name)throws AuthorException;
	public List<Author> getAuthorByFirstName(String name)throws AuthorException;
	public Author getAuthorById(String id)throws AuthorException;
	public Author getAuthorByPhone(String phone)throws AuthorException;
	public List<Author> getAuthorByZip(String zip)throws AuthorException;
	public List<Author> getAuthorByCity(String city)throws AuthorException;
	public List<Author> getAuthorByState(String state)throws AuthorException;
	public String getTotalAuthorByCity(String city)throws AuthorException;
}
