package com.book.portal.entities;

import java.util.List;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity
@Table(name = "titleauthor")
@IdClass(TitleAuthorId.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TitleAuthor {
	
	// Creating a primary key for Title Author Entity
	// Creating many to many relationship between Author and Title with the help of third Entity TitleAuthor
	@Id
    @ManyToOne
    @JoinColumn(name = "au_id", referencedColumnName = "au_id")
    private Author author;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "title_id", referencedColumnName = "title_id")
    private Title title;

    @Column(name = "au_ord")
    private byte auOrd;

    @Column(name = "royaltyper")
    private int royaltyPer;
}

