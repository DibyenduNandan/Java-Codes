package com.book.portal.entities;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

// This class is for creating composite key for Titleauthor Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TitleAuthorId implements Serializable{
	
	private String author;
	private String title;

}
