package com.book.portal.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "authors")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class Author {

	//Creating the  primary key for Author Entity
	@Id
	@Column(name = "au_id", length = 11, nullable = false, columnDefinition = "char(11)")
	@Pattern(regexp = "^[0-9]{3}-[0-9]{2}-[0-9]{4}$", message = "au_id must match the pattern XXX-XX-XXXX")
	private String id;


	

    @Column(name = "au_lname", length = 40, nullable = false)
    private String lastname;

    @Column(name = "au_fname", length = 20, nullable = false)
    private String firstname;


	@Column(name = "phone", length = 12, nullable = false, columnDefinition = "char(12) default 'UNKNOWN'")
	private String phone = "UNKNOWN";

	@Column(name = "address", length = 40)
	private String address;

	@Column(name = "city", length = 20)
	private String city;

	@Column(name = "state", columnDefinition = "char(2)")
	private String state;

	@Column(name = "zip", columnDefinition = "char(5)")
	@Pattern(regexp = "^[0-9]{5}$", message = "zip must be a 5-digit number")
	private String zip;

	@Column(name = "contract", nullable = false)
	private int contract;



}
