package com.book.portal.entities;




import java.util.Date;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity    //marking the Title class as a JPA entity.
@Table(name="titles") //naming the table as titles.
@Data  
@NoArgsConstructor  //By proving these annotation we no need to write the code for these.
@AllArgsConstructor
@ToString
public class Title {   

	@Id   //making Id as the primary key.
	@Column(name="title_id",length=10, nullable=false) // specifying the name for each column.
	private String titleId;
	@Column(name="title", length=80,nullable=false)
	private String title;
	@Column(name="type",length=12,nullable=false, columnDefinition="char(12) default 'UNDECIDED'")
	private String type="UNDECIDED";
	@Column(name="price")
	private double price;
	@Column(name="advance")
	private double advance;
	@Column(name="royalty")
	private int royalty;
	@Column(name="ytd_sales")
	private int ytdSales;
	@Column(name="notes", length=200)
	private String notes;
	@Column(name="pubdate", nullable=false)
	private Date pubDate;

	@ManyToOne   //specifying the annotated field publisher as a many to one relationship.
	@JoinColumn(name="pub_id", referencedColumnName="pub_id")
	private Publisher publisher;
	
	


}