package com.dummy.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerDummy {
	
	@GetMapping("/addComment")
	public String view() {
		return "My name is Avik Roy, this is my dummy project";
	}
	
}