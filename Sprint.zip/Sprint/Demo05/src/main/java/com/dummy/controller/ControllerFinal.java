package com.dummy.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerFinal {

	@GetMapping("/addDisplay")
	public String display() {
		return "My name is Dibyendu Nandan, this is my dummy project";
	}
}
