package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerAyan {
	
		@GetMapping("/display")
		public String display() {
			return "Hello, It is my demo work.";
		}
}

