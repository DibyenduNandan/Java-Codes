package com.dummy.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
<<<<<<<< HEAD:src/main/java/com/dummy/controller/Controller.java
public class Controller {
========
public class EndpointController {
>>>>>>>> e7b13202ceb5c05af4c0d2a19f432bb5558b3420:src/main/java/com/dummy/controller/EndpointController.java
	
	@GetMapping("/endPoint")
	public String respond() {
		return "This is endpoint";
	}
	
}