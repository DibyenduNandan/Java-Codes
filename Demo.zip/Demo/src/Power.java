/*
Exercise 6: Create a class with a method to find the difference between the sum of the squares and the square of the sum of the first n natural numbers.

Method Name
	
calculateDifference  

Method Description
	
Calculate the difference

Argument
	
int n

Return Type
	
int - Sum


Logic
	
Find the difference between the sum of the squares of the first n natural numbers and the square of their sum.
For Example if n is 10,you have to find
(1^2+2^2+3^2+….9^2+10^2)-  
(1+2+3+4+5…+9+10)^2  
 
 */

import java.util.Scanner;

public class Power {
	int checkDifference(int n) {
		int ans;
		int a1=(n*(n+1))/2;
		a1*=a1;
		int a2=(n*(n+1)*((2*n)+1))/6;//385
		ans=a2-a1;
		return ans;
	}
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Power ob=new Power();
		System.out.println("The Difference is "+ob.checkDifference(n));

	}
}
