/*
 
 Handling Multiple Exceptions
Problem Statement:
Write a Java program to demonstrate handling multiple exceptions. Create custom exceptions NegativeNumberException and ZeroValueException. Perform arithmetic operations and handle these exceptions appropriately.
Function Signature:
javaCopy code public static void performOperation(int a, int b) throws NegativeNumberException, ZeroValueException
Input Format:
Two integers a and b.
Output Format:
If both numbers are positive and non-zero, print the result of the division a / b.
If either number is negative, throw a NegativeNumberException with an appropriate message.
If either number is zero, throw a ZeroValueException with an appropriate message.
Sample Input 1:
cssCopy codea = 10, b = 2
Sample Output 1:
makefileCopy codeResult: 5
Sample Input 2:
cssCopy codea = -10, b = 2
Sample Output 2:
mathematicaCopy codeNegative number encountered: -10
 
 
 */

import java.util.Scanner;

class ZeroValueException extends Exception{
	public ZeroValueException(String msg) {
		super(msg);
	}
}

class NegativeNumberException extends Exception{
	public NegativeNumberException(String msg) {
		super(msg);
	}
}
public class MultiExcep {
	public static void performOperation(int a, int b) throws NegativeNumberException, ZeroValueException{
		if(a>0 && b>0) {
//			System.out.println(a+" "+b);
//			System.out.println(a/b);
			System.out.printf("Division is %.2f",a/(double)b);
		}
		else if(a<0 || b<0)
			throw new NegativeNumberException("Negative number encountered: "+Math.min(a, b));
		else
			throw new ZeroValueException("cannot divisible by zero");
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		try {
			performOperation(a, b);
		} catch (NegativeNumberException | ZeroValueException e) {
			System.out.println(e.getMessage());
		}
	}
}
