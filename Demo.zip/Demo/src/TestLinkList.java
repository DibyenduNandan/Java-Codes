import java.util.*;

class Customer{
	private int cust;
	private String name;
	private long ph;
	public int getCust() {
		return cust;
	}
	public void setCust(int cust) {
		this.cust = cust;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public long getPh() {
		return ph;
	}
	public void setPh(long ph) {
		this.ph = ph;
	}
	
	public Customer() {
		
	}
	
	public Customer(int cust,String name,long ph) {
		this.name=name;
		this.cust=cust;
		this.ph=ph;
	}
	
	public String toString() {
		return cust+" "+name;
	}
}

class CustomerService{
	LinkedList<Customer> listOfCustomers = new LinkedList<>();
	public boolean addCustomer(Customer obj) {
		if(listOfCustomers.add(obj))
			return true;
		return false;
	}
	
	public ArrayList<Customer> getAllCustomers(){
//		ArrayList<Customer> ans= new ArrayList<>();
//		ans.addAll(listOfCustomers);
		
		ArrayList<Customer> ans= new ArrayList<>(listOfCustomers);
		return ans;
	}
	
	public Customer getByPhone(long ph) throws Exception {
		for(Customer i: listOfCustomers) {
			if(i.getPh()==ph) {
				return i;
			}
		}
		
		throw new Exception("Phone Number Not found");
	}
	
	public Customer getByName(String name) throws Exception {
		for(Customer i: listOfCustomers) {
			if(i.getName().equals(name)) {
				return i;
			}
		}
		
		throw new Exception("Customer Not found");
	}
	
	
	
}


public class TestLinkList {
	
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		Customer obj1=new Customer(1,"Dibyendu",45637);
		Customer obj2=new Customer(1,"Dev",34628);
		CustomerService ob=new CustomerService();
		System.out.println(ob.addCustomer(obj1));
		System.out.println(ob.addCustomer(obj2));
		
	}

}
