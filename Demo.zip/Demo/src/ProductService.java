import java.util.ArrayList;

public class ProductService  implements ProductInterface{
	
	
	ArrayList<ProductEntity> al=new ArrayList<ProductEntity>();
	
 
	@Override
	public String addProduct(ProductEntity p) {
		boolean result=al.add(p);
		return result+"Prduct added in List";
	}
 
	@Override
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}
 
	@Override
	public ProductEntity searchProduct(int id) {
		// TODO Auto-generated method stub
		return null;
	}
 
	@Override
	public String updateProduct(ProductEntity p) {
		// TODO Auto-generated method stub
		return null;
	}
 
	@Override
	public ArrayList<ProductEntity> listProducts() {
		// TODO Auto-generated method stub
		return al;
	}
 
}
 