import java.util.*;

class Product implements Comparator<Product>{
	String name;    
	double price;
    int quantity;

    Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
    public int getQuantity() {
        return quantity;
    }
    
    @Override
    public int compare(Product o1,Product o2) {
        return o1.name.compareTo(o2.name);
    }
    
    @Override
    public String toString() {
        return name + " ($" + price + ", " + quantity + " units)";
    }
}

class sortByPrice implements Comparator<Product>{

	@Override
	public int compare(Product o1, Product o2) {
		return (int)(o1.getPrice()-o2.getPrice());
	}
	
	
	
}


public class ProductManagement {
	public static void addProduct(List<Product> products, String name, double price, int quantity) {
        products.add(new Product(name, price, quantity));
    }
	
	public static List<Product> sortProductsByName(List<Product> products) {
		Collections.sort(products,new Product(null, 0, 0));
		return products;
	}
	
	public static List<Product> sortByPrice(List<Product> products) {
		Collections.sort(products,new sortByPrice());
		return products;
	}
	
	public static List<Product> sortProductsByQuantity(List<Product> products){
		Collections.sort(products,  (o1,o2) ->{
			return o1.getQuantity()-o2.getQuantity();
		});
		return products;
	}
	
	public static void main(String[] args) {
        List<Product> products = new ArrayList<>();
        addProduct(products, "Laptop", 1000, 10);
        addProduct(products, "Phone", 800, 20);
        addProduct(products, "Tablet", 600, 15);

        System.out.println(sortProductsByName(products)); // Output: [Laptop, Phone, Tablet]
        System.out.println(sortByPrice(products)); // Output: [Tablet, Phone, Laptop]
        System.out.println(sortProductsByQuantity(products)); // Output: [Laptop, Tablet, Phone]
    }
}
