import java.util.Scanner;

public class powe {
	static boolean checkNumber(int n) {
		while(n!=0) {
			//System.out.println(n);
			if(n%2!=0)
				return false;
			n=n>>1;
		}
		return true;
	}
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		boolean ans=powe.checkNumber(n);
		if(ans)
			System.out.println("Number is power of 2");
		else {
			System.out.println("number is not power of 2");
		}
	}
}
