import java.util.*;
abstract class ab{
	public void displ()
	{
		System.out.println("sd");
	}
}

public class hash extends ab{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int marks[]= {4,6,8,9,2,3,5};
		System.out.println(Arrays.asList(marks));
		System.out.println(Collections.min((Collection)Arrays.asList(marks)));
		HashMap<String,String> a = new HashMap<String,String>();
		a.put("A","1");
		a.put("A","2");
		a.put("C","8");
//		List<String> ans = new ArrayList<>();
//		List<String> an=(List<String>)a.values();
		System.out.println(a+" who an i");
		
//		int a[]=new int
	}

}
