import java.util.ArrayList;

public interface ProductInterface {
	
	
	public String addProduct(ProductEntity p);
	public String deleteProduct(int id);
	public ProductEntity searchProduct(int id);
	public String updateProduct(ProductEntity p);
	public ArrayList<ProductEntity> listProducts();
	
 
}