import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Birth {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter person age");
		String string=sc.nextLine();
		LocalDate objDate=LocalDate.parse(string);
		LocalDate end=LocalDate.now();
		Period p=objDate.until(end);
		System.out.println("The age of the person is: "+p.getYears());
	}
}
