import java.util.Scanner;

public class prime {
	static boolean checkPrime(int n) {
		for(int i=2;i<=n/2;i++) {
			if(n%i==0)
				return false;
		}
		return true;
	}
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("The prime numbers are");
		for(int i=2;i<n;i++) {
			if(prime.checkPrime(i))
				System.out.print(i+" ");
		}
	}
}
