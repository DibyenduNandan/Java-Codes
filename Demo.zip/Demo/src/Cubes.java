//Create a method to find the sum of the cubes of the digits of an n digit number

import java.util.Scanner;

public class Cubes {
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int ans=0;
		while(n!=0) {
			int d=n%10;
			ans+=d*d*d;
			n=n/10;
		}
		System.out.println("The sum of cudes of digit of the number is "+ans);
	}
}
