package collection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProductBO  implements ProductService{

	// addAll(Collection c)
	//Set<Product> setOfProduct=new HashSet();
	Set<Product> setOfProduct=null;
	@Override
	public void addProduct(List<Product> products) {
		/*  for(Product p:products)
       {
        setOfProduct.add(p);
       }*/
		//setOfProduct.addAll(products);
		setOfProduct=new HashSet(products);
	}

	@Override
	public Product getProductById(long product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Product> viewAllProducts() {
		// TODO Auto-generated method stub
		return setOfProduct;
	}

	@Override
	public int countProduct() {


		return setOfProduct.size();
	}

	@Override
	public List<Product> serachProductByName(String pName) {
		// TODO Auto-generated method stub
		List<Product> ans=new ArrayList<Product>();
		for(Product i:setOfProduct) {
			if(i.getProductName().equalsIgnoreCase(pName)) {
				ans.add(i);
			}
		}
		return ans;
	}

	@Override
	public double getTotalPrice() {
		// TODO Auto-generated method stub
		double ans=0;
		for(Product i: setOfProduct) {
			ans+=i.getProductPrice();
		}
		return ans;
	}

	@Override
	public List<Product> fetchProductByAlphabet(char ch) {
		// TODO Auto-generated method stub
		List<Product> ans=new ArrayList<Product>();
		for(Product i:setOfProduct) {
			if(i.getProductName().charAt(0)==ch) {
				ans.add(i);
			}
		}
		return ans;
	}

	@Override
	public int removeProduct(long productId) {
		// TODO Auto-generated method stub
		for(Product i: setOfProduct) {
			if(i.getProductId()==productId) {
				setOfProduct.remove(i);
				return 1;
			}
		}
		return -1;
	}

}