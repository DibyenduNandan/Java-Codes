package collection;

import java.util.ArrayList;
import java.util.Collections;

class Citizen {
	private String name;
	private String location;
	private int pincode;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public Citizen(String name, String location, int pincode) {
		super();
		this.name = name;
		this.location = location;
		this.pincode = pincode;
	}
	
	
}
public class CitizenAddress {
	
	public ArrayList<Citizen> showCitizenInAscendingByPin(ArrayList<Citizen> ans){
		Collections.sort(ans, (o1,o2) ->{
			return o1.getPincode()-o2.getPincode();
		});
		
		return ans;
	}
	
	public ArrayList<Citizen> showCitizenInDescendungByPin(ArrayList<Citizen> ans){
		Collections.sort(ans, (o1,o2) ->{
			if(o1.getPincode()>o2.getPincode())
				return -1;
			else
				return 1;
		});
		return ans;
	}
	
	public ArrayList<Citizen> showCitizenInAscendingByLocation(ArrayList<Citizen> ans){
		Collections.sort(ans, (o1,o2) ->{
			return o1.getLocation().compareTo(o2.getLocation());
		});
		
		return ans;
	}
	
	public ArrayList<Citizen> showCitizenInDescendungByLocation(ArrayList<Citizen> ans){
		Collections.sort(ans, (o1,o2) ->{
			if(o1.getLocation().compareTo(o2.getLocation())>0)
				return -1;
			else
				return 1;
		});
		return ans;
	}
	
	public static void main(String[] args) {
		Citizen obj=new Citizen("Dibyendu", "kolkata", 5);
		Citizen obj1=new Citizen("Dibyendu", "Lucknow", 3);
		Citizen obj2=new Citizen("Dibyendu", "Jaipur", 1);
		Citizen obj3=new Citizen("Dibyendu", "Mumbai", 9);
		
		
	}
}
