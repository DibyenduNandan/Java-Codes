package collection;

import java.util.*;


class NagativeValueRException extends Exception{
	public NagativeValueRException(String msg) {
		super(msg);
	}
}

class MovieTicket implements Comparable<MovieTicket>{
	private int numberOfTicket;
	private String movieNameString;
	private double moviePrice;
	public int getNumberOfTicket() {
		return numberOfTicket;
	}
	public void setNumberOfIcket(int numberOfIcket) {
		this.numberOfTicket = numberOfIcket;
	}
	public String getMovieNameString() {
		return movieNameString;
	}
	public void setMovieNameString(String movieNameString) {
		this.movieNameString = movieNameString;
	}
	public double getMoviePrice() {
		return moviePrice;
	}
	public void setMoviePrice(double moviePrice) {
		this.moviePrice = moviePrice;
	}

	public MovieTicket(int numberOfTicket,String movieNameString, double moviePrice) {
		this.numberOfTicket=numberOfTicket;
		this.movieNameString=movieNameString;
		this.moviePrice=moviePrice;
	}
	
	public String toString() {
		return numberOfTicket +" "+ movieNameString + " " + moviePrice;
	}
	
	public int compareTo(MovieTicket obj) {
		System.out.println("Hi"+this);
		System.out.println("hello"+obj);
		if(this.moviePrice>obj.moviePrice)
			return 1;
		return -1;
	}
}
/*
 *add(Object)
 *{
 *if(Movie insatnceOf Comparable)
 *{
 *
 *
 *}
 *}
 * 
 * 
 * 
 */

public class MovieSerice {
	public static Set <MovieTicket> calculateMoviePriceWithGST(TreeSet<MovieTicket> movieTicket) throws NagativeValueRException{
		for(MovieTicket i: movieTicket) {
			if(i.getNumberOfTicket()<0)
				throw new NagativeValueRException(" Number of thicket is negative");
			else {
				double ans=i.getMoviePrice()*0.18+i.getMoviePrice();
				i.setMoviePrice(ans);
			}
		}
		return movieTicket;
	}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		TreeSet <MovieTicket> tickets= new TreeSet<MovieTicket>();
		tickets.add(new MovieTicket(10,"Avenger", 270));
		tickets.add(new MovieTicket(14,"doctor Strange", 200));
		tickets.add(new MovieTicket(16,"Kalki 2898 Ad", 250));
		tickets.add(new MovieTicket(20,"Pathan", 270));

		MovieSerice ob=new MovieSerice();
		try {
			for(MovieTicket i: ob.calculateMoviePriceWithGST(tickets)) {
				System.out.println(i);
			}
		}
		catch (NagativeValueRException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}

	}
}
