package collection;

public class Bucket {
	private String data;
	private int count;
	private  int value;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data=data;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count=count;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value=value;
	}

	public Bucket(String data,int count,int value) {
		this.data=data;
		this.count=count;
		this.value=value;
	}
	public static void main(String[] args) {
		
	}

}

class Test{
	
	public int countChars(String str, char c, Bucket bkt) {
		int count=0;
		for(int i=0;i<str.length();i++) {
			if(str.charAt(i)==c)
				count+=1;
		}
		bkt.setCount(count);
		return count;
	}
	
	public String reverse(String str) {
		String ans="";
		for(int i=str.length()-1;i<=0;i--) {
			ans+=str.charAt(i);
		}
		return ans;
	}
	
	
	public int transfer(String str,Bucket bkt) {
		int n=0;
		try {
			n=Integer.parseInt(str);
			bkt.setValue(n);
			return n;
		}
		catch(NumberFormatException e) {
			System.out.println("Please enter a number");
		}
		finally {
			return n;
		}
	}
}
