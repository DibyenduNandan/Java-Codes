package collection;

import java.util.HashSet;
import java.util.Scanner;

public class ShortestSubstring {
	public static void main(String[] args) {
		String input = "abcfdebmzf";
		int result = findLengthOfShortestUniqueSubstring(input);
		System.out.println(result);
	}

	public static int findLengthOfShortestUniqueSubstring(String s) {
		int n = s.length();
		int shortestLength = Integer.MAX_VALUE;

		for (int len = 1; len <= n; len++) {
			for (int i = 0; i <= n - len; i++) {
				String substring = s.substring(i, i + len);
				String remainingString = s.substring(0, i) + s.substring(i + len);

				if (hasAllUniqueCharacters(remainingString)) {
					shortestLength = Math.min(shortestLength, substring.length());
				}
			}
		}

		return shortestLength == Integer.MAX_VALUE ? 0 : shortestLength;
	}

	private static boolean hasAllUniqueCharacters(String s) {
		HashSet<Character> set = new HashSet<>();
		for (char c : s.toCharArray()) {
			if (set.contains(c)) {
				return false;
			}
			set.add(c);
		}
		return true;
	}
}

