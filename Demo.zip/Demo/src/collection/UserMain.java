package collection;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UserMain {
	public static ArrayList<String> retirementEmployeeList(HashMap<String,String> ans){
		ArrayList<String> a=new ArrayList<>();
		for(Map.Entry<String, String> i: ans.entrySet()) {
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date=LocalDate.parse(i.getValue(),formatter);
			LocalDate current=LocalDate.parse("10/07/2024",formatter);
			Period p=date.until(current);
			if(p.getYears()>=60)
				a.add(i.getKey());
		}
		Collections.sort(a);
		System.out.println(a);
		return a;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Employee");
		int n=sc.nextInt();
		HashMap<String,String> ans=new HashMap<>();
		while(n!=0) {
			System.out.println("Enter Employee Id");
			String id=sc.next();
			System.out.println("Enter date");
			String dt=sc.next();
			ans.put(id, dt);
			n-=1;
		}
		retirementEmployeeList(ans);
	}
}
