package collection;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidateUtility {
	
	public static Validate validateEmployeeName() {
		Validate val = (name) ->{
			return Pattern.matches("[a-zA-Z ]{5,20}", name);
		};
		
		
		
		return val;
	}
	
	public static Validate validateProductName() {
		Validate val = (name) ->{
			return Pattern.matches("[a-zA-Z ][0-9]{5}", name);
		};
		
		return val;
	}
	
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String name=sc.nextLine();
		Validate ob =validateEmployeeName();
		if(ob.validateName(name))
			System.out.println("Employee name is valid");
		else
			System.out.println("Employee name is not valid");
		
		Validate ob1 =validateProductName();
		String pname=sc.nextLine();
		if(ob.validateName(pname))
			System.out.println("Product name is valid");
		else
			System.out.println("Product name is not valid");
		
	}

}
