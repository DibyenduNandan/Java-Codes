package collection;

import java.util.*;

class Candidate  {
	private int candidateId;
	private String candidateName;
	private String candidateCity;
	private int age;
	private String gender;
	private long phone;
	private String emailId;
	public Candidate(int candidateId, String candidateName, String candidateCity, int age, String gender, long phone,
			String emailId) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.candidateCity = candidateCity;
		this.age = age;
		this.gender = gender;
		this.phone = phone;
		this.emailId = emailId;
	}
	public int getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getCandidateCity() {
		return candidateCity;
	}
	public void setCandidateCity(String candidateCity) {
		this.candidateCity = candidateCity;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "Candidate [candidateId=" + candidateId + ", candidateName=" + candidateName + ", candidateCity="
				+ candidateCity + ", age=" + age + ", gender=" + gender + ", phone=" + phone + ", emailId=" + emailId
				+ "]\n";
	}

	public static void main(String[] args) {

	}
}


interface ICandidateService
{
	Set<Candidate> getAllCandidate();
	int countMaleCandidate();

}

class CandidateService implements ICandidateService{
	
	private HashSet<Candidate> ans;
	
	public void addData(List<Candidate> an) {
		ans=new HashSet<>(an);
	}

	@Override
	public Set<Candidate> getAllCandidate() {
		// TODO Auto-generated method stub
		return ans;
	}
	
	@Override
	public int countMaleCandidate() {
		// TODO Auto-generated method stub
		int count=0;
		for(Candidate i:ans) {
			if(i.getGender().equalsIgnoreCase("male"))
				count+=1;
		}
		return count;
	}
	
	public Candidate getYoungestCandidate(){
		Candidate a=Collections.min(ans, (o1,o2)->{
			return Integer.compare(o1.getAge(), o2.getAge());
		});
		
		
		return a;
	}
	
	public List<Candidate> getCandidateBasedOnCity(String city){
		List<Candidate> a=new ArrayList<>();
		for(Candidate i:ans) {
			if(i.getCandidateCity().equalsIgnoreCase(city)) {
				a.add(i);
			}
		}
		return a;
	}
	
	public TreeSet<Candidate> getCandidateInSortedOrder(){
		
		TreeSet<Candidate> a=new TreeSet<>((o1,o2)->{
			return Integer.compare(o1.getCandidateId(),o2.getCandidateId());
		});
		
		a.addAll(ans);
		return a;
	}
	
	public int getAverage() {
		int a1=ans.stream().map(x-> x.getAge()).reduce(0,(a,b)-> a+b);
		return a1/ans.size();
	}
	

	public static void main(String[] args) {
		CandidateService ob=new CandidateService();
		List<Candidate> data = new ArrayList<>();
		data.add(new Candidate(101, "Alice", "New York", 30, "Female", 1234567890L, "alice@example.com"));
		data.add(new Candidate(102, "Bob", "Los Angeles", 25, "Male", 9876543210L, "bob@example.com"));
		data.add(new Candidate(103, "Charlie", "Chicago", 35, "Male", 5678901234L, "charlie@example.com"));
		data.add(new Candidate(104, "Diana", "San Francisco", 28, "Female", 3456789012L, "diana@example.com"));
		data.add(new Candidate(105, "Eve", "Boston", 32, "Female", 7890123456L, "eve@example.com"));
		data.add(new Candidate(106, "Frank", "Chicago", 29, "Male", 9012345678L, "frank@example.com"));
        data.add(new Candidate(107, "Grace", "Austin", 27, "Female", 2345678901L, "grace@example.com"));
        ob.addData(data);
        System.out.println("Number of male candidate: "+ob.countMaleCandidate());
        System.out.println("Youngest Candidate: "+ob.getYoungestCandidate());
        System.out.println("Candidate based on city:\n"+ob.getCandidateBasedOnCity("chicago"));
        System.out.println("Candidate in sorted order:\n"+ob.getCandidateInSortedOrder());
        System.out.println("Average age: "+ob.getAverage());
		
	}
	
}
