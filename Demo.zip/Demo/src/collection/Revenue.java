package collection;

import java.util.Scanner;
import java.util.TreeSet;

class Main implements Comparable<Main>{
	private String revenueCatagory;
	private int amount;
	public String getRevenueCatagory() {
		return revenueCatagory;
	}
	public void setRevenueCatagory(String revenueCatagory) {
		this.revenueCatagory = revenueCatagory;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Main(String revenueCatagory, int amount) {
		super();
		this.revenueCatagory = revenueCatagory;
		this.amount = amount;
	}
	
	public String toString() {
		return revenueCatagory +" "+ amount;
	}
	
	@Override
	public int compareTo(Main o) {
		// TODO Auto-generated method stub
		if(this.getAmount()> o.getAmount())
			return -1;
		return 1;
	}
}

public class Revenue {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		TreeSet<Main> an = new TreeSet<Main>();
		while(true) {
			System.out.println("Enter revenue category");
			String st=sc.nextLine();
//			Sponsorship
			System.out.println("Enter revenue amount");
//			60000
			int amt=sc.nextInt();
			System.out.println("Do you want to continue(yes/no):");
			String ch=sc.next();
			Main obj =new Main(st, amt);
			an.add(obj);
			if(ch.equalsIgnoreCase("no"))
				break;
//			yes
			sc.nextLine();
		}
		System.out.println("Top Spending catagory");
		System.out.println("Catagory   Amount");
		for(Main i: an) {
			System.out.println(i);
		}
		
		int amt=an.stream().map(r->r.getAmount()).reduce(0, (sum,amt1)->sum+amt1);
			
		System.out.println("Total amount earned "+amt);
		
		System.out.println(String.format("%-15s%-15s","Category", "Amount"));
		for(Main i: an) {
			double per=(i.getAmount()/(amt*1.0))*100;
			System.out.println(String.format("%-15s%-15s",i.getRevenueCatagory(),per));
		}
		
	}
}
