package collection;

import java.util.List;
import java.util.Set;

public interface ProductService {
	//The method will store list of products into HashSet
	public void addProduct(List<Product> products);
	public Product getProductById(long product);
	public Set<Product> viewAllProducts();
	public int countProduct();
	public List<Product> serachProductByName(String pName);
	public double getTotalPrice();
	public List<Product> fetchProductByAlphabet(char ch);
	public int removeProduct(long productId);
}
