package collection;

import java.util.*;

class Task {
	private int taskId;
	private String taskName;
	public Task() {

	}
	public Task(int taskId, String taskName) {
		this.taskId = taskId;
		this.taskName = taskName;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", taskName=" + taskName + "]";
	}

}


public class Main2 {

	static TreeMap<Emp, List<Task>> empmap = new TreeMap<>();

	public static List<Task> searchbyempId(int empId){
		int flag=0;
		for(Map.Entry<Emp, List<Task>> data:empmap.entrySet()) {
			if(data.getKey().getEmpId()==empId) {
				flag++;
				return data.getValue();
			}
		}
		if(flag==0) {
			throw new IdNotFouncException("EmpId is invalid");
		}
		return new ArrayList<Task>();
	}

	public static Task[] applicationList(){
		Task[] op=new Task[10];
		int i=0;
		for(Map.Entry<Emp, List<Task>> data:empmap.entrySet()) {
			for(Task task: data.getValue()){
				if(task.getTaskName().endsWith("application")) {
					op[i]=task;
					i++;
				}
			}
		}
		return op;
	}

	public static void main(String[] args) {
//		Map<String, Long> mapp=new TreeMap<>();
//		Scanner sc=new Scanner(System.in);
//		sc.useDelimiter("\r?\n");
//		String choi;
//		do {
//			System.out.println("Enter Data in Map");
//			System.out.println("Enter name");
//			String name=sc.next();
//			System.out.println("Enter runs");
//			Long runs=sc.nextLong();
//			mapp.put(name, runs);
//			System.out.println("Do you want to continue??");
//			choi=sc.next();
//		} while(choi.equalsIgnoreCase("yes"));
//
//		System.out.println(IPLdata.maxRuns(mapp));

	}

}


class IdNotFouncException extends RuntimeException{
	IdNotFouncException(String msg){
		super(msg);
	}
}


class Emp implements Comparable<Emp>{
	private String empName;
	private int empId;
	public Emp() {

	}
	public Emp(String empName, int empId) {
		this.empName = empName;
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "Emp [empName=" + empName + ", empId=" + empId + "]";
	}
	@Override
	public int compareTo(Emp o) {
		return this.empId-o.empId;
	}


}
