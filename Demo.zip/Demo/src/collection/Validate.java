package collection;

public interface Validate {
	public boolean validateName(String name); 
}
