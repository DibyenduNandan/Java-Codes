package collection;


import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class ProductCat
{
	private long productId;
	private String productName;
	private LocalDate productExp;
	private double productPrice;
	public ProductCat(long productId, String productName, LocalDate productExp, double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productExp = productExp;
		this.productPrice = productPrice;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public LocalDate getProductExp() {
		return productExp;
	}
	public void setProductExp(LocalDate productExp) {
		this.productExp = productExp;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productExp=" + productExp
				+ ", productPrice=" + productPrice + "]";
	}
}
class ProductService
{
	static List<ProductCat> listOfProduct;
	public static void addProduct(List<ProductCat> product)
	{
		listOfProduct=product;
	}
	public static Stream<ProductCat> getAllProduct()
	{
		return listOfProduct.stream();
	}
	public static List<ProductCat> getSoretdOrder()
	{
		return listOfProduct.stream().sorted().collect(Collectors.toList());
	}
	public static ProductCat getProdctById(long productId) {
		/*
		 *
		 * boolean test(T t)
		 *
		 *
		 */
		return listOfProduct.stream().
				filter(p->  p.getProductId()==productId).
				collect(Collectors.toList()).get(0);
	}
	public static double getTotalPrice()
	{
		return 0.0;
	}
	public static int getNumberOfProduct()
	{
		return 0;
	}
	public static Set<Product> getProductByExpry(LocalDate ld)
	{
		return null;
	}
	public static ProductCat maxPrice()
	{
		Comparator<ProductCat> cmp=
				(p1,p2)->p1.getProductPrice()>p2.getProductPrice()?1:-1;
				Optional<ProductCat>opt=listOfProduct.stream().max(cmp);
				return opt.get();
	}
	public static List<ProductCat> getProductByName(String pName)
	{
		return null;
	}
}
public class Product1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
