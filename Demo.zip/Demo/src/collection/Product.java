package collection;


import java.time.LocalDate;

public class Product {
	private long productId;
	private String productName;
	private LocalDate pMfd;
	private double productPrice;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public LocalDate getpMfd() {
		return pMfd;
	}
	public void setpMfd(LocalDate pMfd) {
		this.pMfd = pMfd;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(long productId, String productName, LocalDate pMfd, double productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.pMfd = pMfd;
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", pMfd=" + pMfd + ", productPrice="
				+ productPrice + "]";
	}

}
