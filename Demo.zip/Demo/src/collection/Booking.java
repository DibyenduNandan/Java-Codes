package collection;

import java.time.LocalDate;
import java.time.Period;

class TravelDateException extends Exception{
	public TravelDateException(String msg) {
		super(msg);
	}
}

class NegativeValueException extends Exception{
	public NegativeValueException(String msg) {
		super(msg);
	}
}

class TicketBooking{
	private String passengerName;
	private LocalDate travelDate;
	private int noOfTickets;
	private double eachTicketAmount;
	
	
	
	public String getPassengerName() {
		return passengerName;
	}



	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}



	public LocalDate getTravelDate() {
		return travelDate;
	}



	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}



	public int getNoOfTickets() {
		return noOfTickets;
	}



	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}



	public double getEachTicketAmount() {
		return eachTicketAmount;
	}



	public void setEachTicketAmount(double eachTicketAmount) {
		this.eachTicketAmount = eachTicketAmount;
	}



	public TicketBooking(String passengerName, LocalDate travelDate, int noOfTickets, double eachTicketAmount) {
		super();
		this.passengerName = passengerName;
		this.travelDate = travelDate;
		this.noOfTickets = noOfTickets;
		this.eachTicketAmount = eachTicketAmount;
	}
	
	
}

public class Booking {
	
	public static String validate(TicketBooking tbk) throws TravelDateException,NegativeValueException{
		Period p =tbk.getTravelDate().until(LocalDate.now());
		if(p.getDays()>0)
			throw new TravelDateException("Date is earlier than current date");
		else {
			if(tbk.getNoOfTickets()<0)
				throw new NegativeValueException("No of tickets cannot be negative");
			else {
				return "Successfully validate";
			}
		}
			
	}
	
	public double computeBillAmount(TicketBooking tbk) {
		double total=0;
		try {
			validate(tbk);
			total=tbk.getEachTicketAmount()*tbk.getNoOfTickets();
		}
		catch (TravelDateException  e) {
			total=0;
			System.out.println(e.getMessage());
		}
		catch (NegativeValueException e) {
			total=-1;
			System.out.println(e.getMessage());
		}
		return total;
	}
	
	public static void main(String[] args) {
		TicketBooking ob1=new TicketBooking("Dibyendu",LocalDate.parse("2024-07-09"), 10, 9);
		TicketBooking ob2=new TicketBooking("Dibyendu",LocalDate.parse("2024-07-10"), -4, 9);
		TicketBooking ob3=new TicketBooking("Dibyendu",LocalDate.parse("2024-07-12"), 10, 9);
		Booking obj=new Booking();
		System.out.println(obj.computeBillAmount(ob1));
		System.out.println(obj.computeBillAmount(ob2));
		System.out.println(obj.computeBillAmount(ob3));
	}
}
