package collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.TreeMap;

enum MyWork {
	training,development,hr;
}



public class TestQueueDemo {
	Queue<MyWork> q=new LinkedList();
	void registerWork(MyWork work)
	{
		//
		q.offer(work);
	}


	int viewNumberOfWork()
	{
		return 0;
	}
	public List<MyWork> getAllWork()
	{
		List<MyWork> listOfWordk=new ArrayList(q);
		return listOfWordk;
	}

	void remove(MyWork workName)
	{
		q.poll();


	}
	public List<MyWork> getFrequestUsedWork()
	{
		TreeMap<String,Integer> tm=new TreeMap();
		for(MyWork w:q)
		{   
			String n=	   w.name();
			tm.put(n, tm.getOrDefault(n, 0)+1);

		}

	}



	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);

		System.out.println("enter work");
		TestQueueDemo tObj=new TestQueueDemo();
		for(int i=0; i<3; i++)
		{
			String workName=sc.next();


			MyWork wk=MyWork.valueOf(workName);
			wk.name();
			tObj.registerWork(wk);
		}
		tObj.getAllWork().forEach(w->System.out.println(w));
	}

}
