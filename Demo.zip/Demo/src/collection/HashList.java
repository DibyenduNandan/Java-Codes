package collection;

import java.util.HashMap;
import java.util.Scanner;

class PLayer{
	String name;
	String team;
	String skill;
	public PLayer(String name, String team, String skill) {
		this.name = name;
		this.team = team;
		this.skill = skill;
	}
	
	public String toString() {
		return name+"---"+team+"---"+skill;
	}
	
}


public class HashList {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Player");
		int n=sc.nextInt();
		HashMap<Integer,PLayer> ans=new HashMap<>();
		int i=1;
		while(n!=0) {
			System.out.println("Enter details of player "+i);
			int id=sc.nextInt();
			sc.nextLine();
			String name=sc.nextLine();
			String team=sc.nextLine();
			String skill=sc.nextLine();
			ans.put(id,new PLayer(name, team, skill));
			n-=1;
			i+=1;
		}
		
		System.out.println("Enter the jersery number to be searched");
		int s=sc.nextInt();
		if(ans.containsKey(s))
			System.out.println(ans.get(s));
		else
			System.out.println("Jersery Not found");
		
	}
}
