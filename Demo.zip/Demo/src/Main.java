import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("fs");
		
		Scanner sc = new Scanner(System.in);
		String s=sc.nextLine();
		String a[]=s.split(" ");
//		List<ArrayList<String>> an = new ArrayList<ArrayList<String>> ();
		List<String> t = Arrays.asList(a);
		ArrayList<String> ans= new ArrayList<String>(t);
		System.out.println(ans);
//		an.add(t);
		
		LocalDate dt1 = LocalDate.parse("2024-07-09");
		LocalDate dt2 = LocalDate.now();
		Period p = Period.between(dt1, dt2);
		p = dt1.until(dt2);
		System.out.println(p.getDays());
	}
}
