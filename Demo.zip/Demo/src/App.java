public class App
{
	public int countOfProduct(product [] p)
	{
		return p.length;
	}

	public void display(int a,int b, String...strings )
	{
		System.out.println(a);
		System.out.println(b);
		for(String s:strings)
		{
			System.out.println(s);
		}
	}

	public product productOfMaxPrice(product[] p)
	{
		product temp=null;
		for(int i=0;i<p.length;i++)
		{
			for(int j=0;j<p.length;j++)
			{
				if(p[i].getProductPrice()>p[j].getProductPrice())
				{
					temp=p[i];
				}
			}


		}
		return temp;
	}




	public static void main(String[] args) {

		product[] Product=new product[3];

		Product[0]=new product(1,"TV",200,20);
		Product[1]=new product(2,"CPU",300,25);
		Product[2]=new product(3,"Mouse",100,10);

		App a=new App();

		a.display(12, 2);
		a.display(12, 2,"A");
		a.display(0, 0, "A","B","C");

		System.out.println(a.countOfProduct(Product));

		product maxPrice=a.productOfMaxPrice(Product);
		System.out.println(maxPrice);

		for(product p:Product)
		{
			System.out.println(p);
		}



	}
}
