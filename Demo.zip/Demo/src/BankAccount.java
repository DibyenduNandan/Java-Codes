import java.util.Scanner;

class InsufficientFundsException extends Exception{
	public  InsufficientFundsException(String msg) {
		super(msg);
	}
}

class NegativeAmountException extends Exception{
	public  NegativeAmountException(String msg) {
		super(msg);
	}
}


class Account{
	private double dep;

	public double getDep() {
		return dep;
	}

	public void setDep(double dep) {
		this.dep = dep;
	}

	public void deposit(double amt)  throws NegativeAmountException{
		if(amt<0)
			throw new NegativeAmountException("Invalid amount :"+amt);
		dep+=amt;
	}

	public void withdraw(double amt)  throws NegativeAmountException,InsufficientFundsException{
		if(amt>dep) {
			throw new InsufficientFundsException("Insufficient amount. Current balance :"+dep);
		}
		if(amt<0)
			throw new NegativeAmountException("Invalid amount :"+amt);
		dep-=amt;
	}

	public double getBalance() {
		return dep;
	}

}

public class BankAccount{
	public static void main(String[] args) {
		String amt;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Account ob=new Account();
		ob.setDep(0.0);
		sc.nextLine();
		while(n!=0) {
			amt=sc.nextLine();
			String st[]=amt.split(" ");
			double a=Double.parseDouble(st[1]);
			if(st[0].equalsIgnoreCase("withdraw")) {
				try {
					ob.withdraw(a);
				} catch (NegativeAmountException | InsufficientFundsException e) {
					System.out.println(e.getMessage());
				}
			}
			else if(st[0].equalsIgnoreCase("deposit")) {
				try {
					ob.deposit(a);
				} catch (NegativeAmountException e) {
					System.out.println(e.getMessage());
				}
			}
			n-=1;
		}
		ob.getBalance();
	}
}
