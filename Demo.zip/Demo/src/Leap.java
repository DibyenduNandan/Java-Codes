import java.time.LocalDate;
import java.util.Scanner;

public class Leap {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date");
		String d=sc.nextLine();
		LocalDate p=LocalDate.parse(d);
		if(p.isLeapYear())
			System.out.println("it is a Leap Year");
		else {
			System.out.println("it is not a Leap Year");
		}
	}
}
