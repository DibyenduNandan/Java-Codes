//Create a class with a method which can calculate the sum of first n natural numbers which are divisible by 3 or 5.

import java.util.Scanner;

public class Cal {
	static int calculateSum(int n){
		int ans=0;
		for(int i=1;i<=n;i++) {
			if(i%3==0 || i%5==0)
				ans+=i;
			//System.out.println(ans);
		}
		return ans;
	}
	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("the sum is "+Cal.calculateSum(n));
	}
}
