/*

 Parsing Integers from a String
Problem Statement:
Write a Java program to parse integers from a comma-separated string and handle NumberFormatException. Create a custom exception called InvalidNumberException that is thrown when an invalid number is encountered.
Function Signature:
javaCopy code public static List<Integer> parseNumbers(String str) throws InvalidNumberException
Input Format:
A string str containing comma-separated values.
Output Format:
A list of integers parsed from the string.
If an invalid number is encountered, throw an InvalidNumberException with an appropriate message.
Sample Input 1:
makefileCopy codestr = "1, 2, 3, 4, 5"
Sample Output 1:
csharpCopy code[1, 2, 3, 4, 5]
Sample Input 2:
makefileCopy codestr = "1, 2, three, 4, 5"
Sample Output 2:
yamlCopy codeInvalid number: three


 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class InvalidNumberException extends  Exception{
	public InvalidNumberException(String msg) {
		super(msg);
	}
}

public class NumberParse {

	public static List<Integer> parseNumbers(String str) throws InvalidNumberException{
		List<Integer> ans=new ArrayList<>();
		String st[]=str.split(",");
		for(String i :st) {
			try {
				int a=Integer.parseInt(i);
				ans.add(a);
			}
			catch(NumberFormatException e) {
				throw new InvalidNumberException("Invalid Number :"+i);
			}
		}
		return ans;
	}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String st = sc.nextLine();
		try {
			List<Integer> ans=parseNumbers(st);
			System.out.println(ans);
		} catch (InvalidNumberException e) {
			System.out.println(e.getMessage());
		}

	}

}
