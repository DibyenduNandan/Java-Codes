import java.util.ArrayList;
import java.util.Scanner;

public class Main1 {
	
	public static void main(String[] args) {
		
	
		Scanner s=new Scanner(System.in);
		ProductService ps=new ProductService();
		
		int choice;
		System.out.println("Press 1 to add the Product");
		System.out.println("Pressc2 to delete the Product");
		
		System.out.println("Press 3 to search the Product");
		System.out.println("Press 4 to update the Product");
		System.out.println("Press 5 to view Product List");
		choice=s.nextInt();
		switch(choice)
		{
		case 1:
				ProductEntity p=new ProductEntity(1,"TV",12.23,12);
				String msg=ps.addProduct(p);
				System.out.println(msg);
				Display d=new Display() {
					
					@Override
					public String display() {
						// TODO Auto-generated method stub
						return "Inner Class";
					}
				};
			
				System.out.println(d.display());
		case 5:
				ArrayList<ProductEntity> plist=ps.listProducts();
				for(ProductEntity product:plist)
				{
					System.out.println(product);
				}
		}
		
	}
 
}