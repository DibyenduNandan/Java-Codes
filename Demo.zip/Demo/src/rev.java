/*
 Reverse a String
Problem Statement:Write a function reverseString that takes a string str as input and returns the reversed string.
Function Signature:
javaCopy codepublic static String reverseString(String str) {
    // Your code here
}
 */




import java.util.Scanner;

public class rev {
	public static String reverseString(String str) {
		String ans="";
		for(int i=str.length()-1;i>=0;i--) {
			ans+=str.charAt(i);
		}
		return ans;
	}
	public static void main(String[] args) {
		System.out.println("Enter a String");
		Scanner sc=new Scanner(System.in);
		String n=sc.nextLine();
		System.out.println("Reversed String is "+rev.reverseString(n));
	}
}
