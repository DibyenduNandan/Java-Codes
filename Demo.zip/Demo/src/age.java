/*
 
 Age Validation
Problem Statement:
Write a Java program to validate the age of a person. Create a custom exception called InvalidAgeException that is thrown when the age is not within the valid range (0-150).
Function Signature:
javaCopy codepublic static void validateAge(int age) throws InvalidAgeException
Input Format:
An integer age.
Output Format:
If the age is valid, print "Valid age: <age>".
If the age is not valid, throw an InvalidAgeException with an appropriate message.
Sample Input 1:
makefileCopy codeage = 25
Sample Output 1:
yamlCopy codeValid age: 25
 
 
 */

import java.util.Scanner;

class InvalidAgeException extends Exception{
	public InvalidAgeException(String msg) {
		super(msg);
	}
}
public class age {
	public static void validateAge(int age) throws InvalidAgeException{
		if(age<0 || age>150)
			throw new InvalidAgeException("Age not valid");
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		try {
			validateAge(age);
			System.out.println("Valid age: "+age);
		} catch (InvalidAgeException e) {
			System.out.println(e.getMessage());
		}
	}

}
