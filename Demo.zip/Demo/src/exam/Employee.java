package exam;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.TreeSet;

class People{
	private int id;
	private String name;
	private LocalDate dt;

	public LocalDate getDt() {
		return dt;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	public void setDt(LocalDate dt) {
		this.dt = dt;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public People(int id,String name,LocalDate dt) {
		this.id=id;
		this.name=name;
		this.dt=dt;
	}

	public People() {

	}
	
	@Override
	public String toString() {
		return id+" "+name+" "+dt;
	}

}


public class Employee{
	private List<People> ans;

	public void setAns(List<People> ans) {
		this.ans=ans;
	}

	public List<People> getAns(){
		return ans;
	}

	public static void main(String[] args) {
		
//		int arr[]= {1,2,3,4};
//		int arr[]=new int[10];
//		System.out.println(Arrays.asList(arr));
//		List<Integer> list= Arrays.asList(1,2,5,3);// This is working
//		Collections.min(list);
//		List list2= Arrays.asList(arr);
//		List<Integer> li2=new ArrayList<Integer>(list2);
//		List<Integer> li3=new ArrayList<Integer>();
//		li2.addAll(list2);
//		for(Integer i: li2)
//			System.out.println(i);
		
		PriorityQueue<Integer> a4=new PriorityQueue<>();
		a4.offer(4);
		a4.offer(1);
		a4.offer(2);
		a4.offer(9);
		a4.offer(5);
		System.out.println(a4);
		
		PriorityQueue<People> a5=new PriorityQueue<>((o1,o2)-> Integer.compare(o1.getId(), o2.getId()));
		
		People emp1 = new People (1, "John Doe", LocalDate.of(2023, 7, 20));
		People  emp2 = new People (2, "Jane Smith", LocalDate.of(2024, 1, 15));
		People  emp3 = new People (3, "Alice Johnson", LocalDate.of(2022, 12, 5));
		People  emp4 = new People (4, "Bob Brown", LocalDate.of(2023, 3, 10));
		
		a5.offer(emp1);
		a5.offer(emp4);
		a5.offer(emp2);
		a5.offer(emp3);
		System.out.println(a5);
		
		
		
		List<People> an=new ArrayList<>();
		an.add(emp1);
		an.add(emp2);
		an.add(emp3);
		an.add(emp4);
		
		People p1=Collections.min(an,(o1,o2)->{
			return Integer.compare(o1.getId(),o2.getId());
		});
		System.out.println(p1);
		
		TreeSet<People> check1=new TreeSet<>((o1,o2)->{
			return o1.getName().compareTo(o2.getName());
		});
		
		List<People> gkuList=new ArrayList<People>(check1);
		check1.add(emp1);
		check1.add(emp2);
		check1.add(emp3);
		check1.add(emp4);
		System.out.println(check1);
		
		
		TreeSet<Integer> check2=new TreeSet<>();
		check2.add(1);
		check2.add(5);
		check2.add(2);
		check2.add(9);
		System.out.println(check2);

		Employee obj=new Employee();
		obj.setAns(an);

		Collections.sort(obj.ans,(People o1,People o2)->{
			return Integer.compare(o1.getId(),o2.getId());
		});
		
		System.out.println(obj.ans);

		Collections.sort(obj.ans,(o1,o2)->{

			int p=(int)o1.getDt().until(o2.getDt(),ChronoUnit.DAYS); // Return type is long
			return -1*p;

//			if(o1.getDt().isAfter(o2.getDt()))
//			{
//				return 1;
//			}
//			else if(o1.getDt().isBefore(o2.getDt()))
//				return -1;
//			else 
//				return 0;
		});
		
		System.out.println(obj.ans);
		

	}
}
