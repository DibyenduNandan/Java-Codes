package exam;
import java.util.*;

public class Grossery {
	public static void main(String[] args) {
		// Sample Input
		List<String[]> prices = Arrays.asList(
				new String[]{"Banana", "10"},
				new String[]{"Apple", "20"},
				new String[]{"Orange", "5"}
				);
		List<String[]> discounts = Arrays.asList(
				new String[]{"Orange", "10"},
				new String[]{"Banana", "10"}
				);
		List<String[]> purchases = Arrays.asList(
				new String[]{"Banana", "5"},
				new String[]{"Orange", "3"}

				);

		GroceryReceipt receipt = new GroceryReceipt();
		List<List<String>> invoice = receipt.generateInvoice(prices, discounts, purchases);

		if(invoice.isEmpty())
			System.out.println("I am Empty");

		for (List<String> item : invoice) {
			System.out.println(item.toString());
		}
	}

}
abstract class GroceryReceiptBase {
	abstract List<List<String>> generateInvoice(List<String[]> prices, List<String[]> discounts, List<String[]> purchases);
}

class GroceryReceipt extends GroceryReceiptBase {
	@Override
	public List<List<String>> generateInvoice(List<String[]> prices, List<String[]> discounts, List<String[]> purchases) {
		HashMap<String, Integer> a =new HashMap<>();
		for(String i[]: prices) {
			a.put(i[0], Integer.parseInt(i[1]));
		}


		HashMap<String, Integer> b =new HashMap<>();
		for(String i[]: discounts) {
			b.put(i[0], Integer.parseInt(i[1]));
		}

//		    	TreeMap<String, Integer> c =new TreeMap<>((String o1,String o2)->{
//		    		return o1.compareTo(o2);
//		    	});
		
//		TreeMap<String, Integer> c =new TreeMap<>((o1,o2)->{
//    		return o1.compareTo(o2);
//    	});

		HashMap<String, Integer> c =new HashMap<>();
		for(String[] i: purchases) {
			if(c.containsKey(i[0])) 
				c.put(i[0],c.get(i[0])+Integer.parseInt(i[1]));
			else
				c.put(i[0], 1);
		}

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);

		List<List<String>> ab=new ArrayList<List<String>>();
		List<String> st ;
		for(Map.Entry<String, Integer> i: c.entrySet()) {
			st= new ArrayList<>();
			String s="";
			double val=i.getValue()*a.get(i.getKey());
			s+=val+" ";
			if(b.containsKey(i.getKey())) {
				val-=val*(b.get(i.getKey())/100.0);
			}
			s+=val;
			st.add(i.getKey());
			st.add(s);
			ab.add(st);
		}

		Collections.sort(ab, (o1,o2)->{
			return -1*o1.get(0).compareTo(o2.get(0));
		});

		return ab;
	}
}
