package exam;

import java.util.*;

class InvalidJobException extends Exception {
    public InvalidJobException(String message) {
        super(message);
    }
}

class Job 
//implements Comparable<Job> 
{
    private int jobId;
    private String jobName;
    private int jobPriority;

    public Job() {
        // Default constructor
    }

    public Job(int jobId, String jobName, int jobPriority) throws InvalidJobException {
        if (jobPriority <= 0 || jobPriority > 10) {
            throw new InvalidJobException("Invalid job priority: " + jobPriority);
        }
        this.jobId = jobId;
        this.jobName = jobName;
        this.jobPriority = jobPriority;
    }

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public int getJobPriority() {
        return jobPriority;
    }

    public void setJobPriority(int jobPriority) throws InvalidJobException {
        if (jobPriority <= 0 || jobPriority > 10) {
            throw new InvalidJobException("Invalid job priority: " + jobPriority);
        }
        this.jobPriority = jobPriority;
    }

//    @Override
//    public int compareTo(Job other) {
//        return Integer.compare(other.jobPriority, this.jobPriority); // Higher priority first
//    }

    @Override
    public String toString() {
        return "Job{" +
                "jobId=" + jobId +
                ", jobName='" + jobName + '\'' +
                ", jobPriority=" + jobPriority +
                '}';
    }
}

enum JobState {
    PROCESSING,
    CANCELLED
}

class JobStatus {
    private int jobId;
    private String jobName;
    private JobState jobState;

    public JobStatus(int jobId, String jobName, JobState jobState) {
        this.jobId = jobId;
        this.jobName = jobName;
        this.jobState = jobState;
    }

    public int getJobId() {
        return jobId;
    }

    public String getJobName() {
        return jobName;
    }

    public JobState getJobState() {
        return jobState;
    }

    @Override
    public String toString() {
        return "JobStatus{" +
                "jobId=" + jobId +
                ", jobName='" + jobName + '\'' +
                ", jobState=" + jobState +
                '}';
    }
}

class JobProcessor {
    public void registerJob(Queue<Job> queue, Job job) {
        queue.offer(job);
    }

    public PriorityQueue<JobStatus> processJob(Queue<Job> queue) {
        PriorityQueue<JobStatus> jobStatuses = new PriorityQueue<>((js1, js2) -> Integer.compare(js2.getJobId(), js1.getJobId()));
        while (!queue.isEmpty()) {
            Job job = queue.poll();
            JobState state;
            switch (job.getJobName().toLowerCase()) {
                case "printing":
                case "editing":
                    state = JobState.valueOf("PROCESSING");
                    break;
                case "saving":
                case "refreshing":
                    state = JobState.PROCESSING;
                    break;
                default:
                    state = JobState.CANCELLED;
            }
            jobStatuses.add(new JobStatus(job.getJobId(), job.getJobName(), state));
        }
        return jobStatuses;
    }
}

public class UserJob {
    public static void main(String[] args) {
        try {
            Queue<Job> jobQueue = new PriorityQueue<>((o1,o2)->{
            	return Integer.compare(o1.getJobPriority(), o2.getJobPriority());
            });
            JobProcessor processor = new JobProcessor();

            processor.registerJob(jobQueue, new Job(1, "printing", 5));
            processor.registerJob(jobQueue, new Job(2, "editing", 8));
            processor.registerJob(jobQueue, new Job(3, "saving", 3));
            processor.registerJob(jobQueue, new Job(4, "invalidJob", 6));

           PriorityQueue<JobStatus> processedJobs = processor.processJob(jobQueue);

            while (!processedJobs.isEmpty()) {
                System.out.println(processedJobs.poll());
            }

        } catch (InvalidJobException e) {
            System.err.println(e.getMessage());
        }
    }
}

