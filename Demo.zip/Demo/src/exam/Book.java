package exam;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Book {
	private String title;
	private String genre;
	private String author;
	private int quantity;
	private double price;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Book(String title, String genre, String author, int quantity, double price) {
		super();
		this.title = title;
		this.genre = genre;
		this.author = author;
		this.quantity = quantity;
		this.price = price;
	}

	public Book() {

	}
	
	public String toString() {
		return title+" "+genre+" "+author+" "+quantity+" "+price;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.nextLine();
		List<Book> b=new ArrayList<>();
		while(n!=0) {
			String st = sc.nextLine();
			String a []=st.split(":");
			b.add(new Book(a[0], a[1], a[2], Integer.parseInt(a[3]), Double.parseDouble(a[4])));
			n-=1;
		}
		
		BookUtility obj = new BookUtility();
		Map<String, List<Book>>ans=obj.retrieveBooksGroupedByGenre(b.stream());
		System.out.println(ans);
		
		System.out.println(obj.getAuthorsAndPricesByTitle(b.stream(), ""));
	}
}

class BookUtility{
	public Map<String, List<Book>> retrieveBooksGroupedByGenre(Stream<Book> books){
		//books.map(x->x.getGenre()).collect(, , )
		List<Book> an=books.toList();
		Map<String, List<Book>> ans=new  HashMap<String, List<Book>>();
		for(Book i:an) {
			ans.put(i.getGenre(), new ArrayList<Book>());
		}

		for(Book i:an) {
			ans.get(i.getGenre()).add(i);
		}

		return ans;
		//		return books.collect(Collectors.groupingBy(b->b.getGenre()));
	}

	public Map<String, Double> getAuthorsAndPricesByTitle(Stream<Book> books, 
			String title){


		/*	return books.filter(x->x.getTitle().equals(title)
		).collect(Collectors.toMap(b->b.g))*/

		return books.filter(b->b.getTitle().equals(title)).collect(Collectors.toMap(b1->b1.getAuthor(),b1->b1.getPrice()));
	}

	public Stream<String> generateSummaryReport(List<Book> books){
		int t=0,quentity=0;
		double price=0;
		String ans[]=new String[3];
		for(Book i:books) {
			t+=1;
			price+=i.getPrice()*i.getQuantity();
			quentity+=i.getQuantity();
		}
		ans[0]="Total Book: "+t;
		ans[1]="Total Price: "+price;
		ans[2]="Total Quantity: "+quentity;
		
		return Arrays.stream(ans);
	}
}
