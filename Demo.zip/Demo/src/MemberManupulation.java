import java.util.*;

class Member{
	private int memberId;
	private String memberName;
	private Address address;
	
	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Member() {
		
	}
	
	public Member(int memberId,String memberName, Address address) {
		this.memberId=memberId;
		this.address=address;
		this.memberName=memberName;
	}
	
	public String toString() {
		return "Id :"+memberId+"\n"+"Name :"+memberName+" "+address;
	}
}

class Address{
	long addressId;
	String cityName;
	long pinCode;
	
	
	public Address(long addressId, String cityName, long pinCode) {
		this.addressId = addressId;
		this.cityName = cityName;
		this.pinCode = pinCode;
	}


	public String toString() {
		return "Address :"+cityName;
	}
}

class Library implements Comparator<Member>{
	List <Member> memberList = new ArrayList<Member>();
	public void addMember(Member memberObj) {
		memberList.add(memberObj);
	}
	
	public List<Member> viewAllMember(){
		return memberList;
	}
	
	public List<Member> sortMemberBasedListOn(){
		Collections.sort(memberList, (m1,m2)->{
			if(m1.getMemberId()>m2.getMemberId())
			{
				return 1;
			}
			return -1;
			
		});
		return memberList;
	}
	
	
	
	public ArrayList<Member> fetchAllMemberFromKolkata(){
		ArrayList<Member> ans=new ArrayList<>();
		for(Member i:memberList ) {
			if(i.getAddress().cityName.equalsIgnoreCase("Kolkata"))
				ans.add(i);
		}
		return ans;
	}
	
	
}
public class MemberManupulation {
	public static void main(String[] args) {
//		Member member=new Member(9, "xyz", new Address(8, "kokatat", 100));
		Scanner sc=new Scanner(System.in);
		Library obj=new Library();
		while (true) {
			System.out.println("1. Add Member");
			System.out.println("2. View Members");
			System.out.println("3. Sort Member by address");
			System.out.println("4. Exit"); 
			System.out.println("Enter your choice");
			int ch=sc.nextInt();
			if(ch==1) {
				System.out.println("Enter the Id:");
				int id=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the name:");
				String name =sc.nextLine();
				System.out.println("Enter the address:");
				String addr =sc.nextLine();
				System.out.println("Enter the address Id:");
				long addrId =sc.nextLong();
				System.out.println("Enter the Pincode:");
				long pin =sc.nextLong();
				
				Member obMember=new Member(id,name,new Address(addrId, addr, pin));
				obj.addMember(obMember);
			}
			else if(ch==2) {
				for(Member i: obj.viewAllMember()) {
					System.out.println(i);
				}
			}
			else if(ch==3) {
				for(Member i:obj.sortMemberBasedListOn()){
					System.out.println(i);
				}
			}
			else 
				break;
		}
	}

}
