import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.stream.Stream;

public class Format {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date");
		String d=sc.nextLine();
		LocalDate date=LocalDate.parse(d);
		System.out.println(date.getDayOfWeek());
		LocalDateTime datetime = LocalDateTime.now();
		System.out.println(date+" "+datetime);
		DateTimeFormatter obj1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		DateTimeFormatter obj2=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		DateTimeFormatter obj3=DateTimeFormatter.ofPattern("MMM dd, yyyy");
		DateTimeFormatter obj4=DateTimeFormatter.ofPattern("EEEE, MMM dd, yyyy HH:mm:ss");
		String ans1=obj1.format(date);
		String ans2=obj2.format(date);
		String ans3=obj3.format(date);
		String ans4=obj4.format(datetime);
		System.out.println(ans1);
		System.out.println(ans2);
		System.out.println(ans3);
		System.out.println(ans4);
		
		
	}
}
