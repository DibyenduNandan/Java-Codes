/*
 
 [Yesterday 16:49] Gupta, Manish
Use Regex pattern and matcher to solve below problem
 
Validating Email Addresses
Problem Statement:
Write a Java program to validate email addresses. Create a custom exception called InvalidEmailException that is thrown when an email address does not match the specified pattern.
Function Signature:
javaCopy code public static void validateEmail(String email) throws InvalidEmailException
Input Format:
A string email.
Output Format:
If the email is valid, print "Valid email: <email>".
If the email is not valid, throw an InvalidEmailException with an appropriate message.
Sample Input 1:
makefileCopy codeemail = "test@example.com"
Sample Output 1:
bashCopy codeValid email: test@example.com
Sample Input 2:
makefileCopy codeemail = "invalid-email"
Sample Output 2:
yamlCopy codeInvalid email: invalid-email
 
 
*/

import java.util.Scanner;
import java.util.regex.Pattern;

class InvalidEmailException extends Exception{
	public InvalidEmailException(String msg) {
		super(msg);
	}
}

public class ValidEmail {
	public static void validateEmail(String email) throws InvalidEmailException{
		boolean c=Pattern.matches("[A-Za-z]+[@][A-Za-z]+(.com)", email);
		if(!c)
			throw new InvalidEmailException("Invalid Email: "+email);
		System.out.println(c);
//		if(!email.matches("[A-Za-z]+@[A-Za-z]+.com"))
//			throw new InvalidEmailException("Invalid Email: "+email);
//		System.out.println(c);
	}
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		String email =sc.nextLine();
		try {
			validateEmail(email);
			System.out.println("Valid Email: "+email);
		} catch (InvalidEmailException e) {
			System.out.println(e.getMessage());
		}
	}
}


