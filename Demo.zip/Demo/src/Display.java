
public interface Display {
	
	public String display();

}
