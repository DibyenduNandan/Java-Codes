package com.bookpartnerportal.BookPartnerPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookPartnerPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
