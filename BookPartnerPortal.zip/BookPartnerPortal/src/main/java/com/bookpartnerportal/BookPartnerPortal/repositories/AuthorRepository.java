package com.bookpartnerportal.BookPartnerPortal.repositories;

public class AuthorRepository {

}
